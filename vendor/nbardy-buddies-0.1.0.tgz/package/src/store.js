import {
  appendFileSync,
  existsSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  realpathSync,
  renameSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { homedir } from "node:os";
import { dirname, isAbsolute, join, relative, resolve } from "node:path";
import { createHash, randomUUID } from "node:crypto";
import { DatabaseSync } from "node:sqlite";

export const BUDDY_STATUSES = ["active", "paused", "archived"];
export const SPRINT_STATUSES = ["planned", "active", "completed", "cancelled"];
export const WORK_ITEM_STATUSES = [
  "backlog",
  "ready",
  "in_progress",
  "blocked",
  "review",
  "done",
  "cancelled",
];
export const CONVERSATION_STATUSES = ["active", "complete", "failed", "cancelled"];
export const BUDDY_PROJECT_STATUSES = [...WORK_ITEM_STATUSES];
export const BUDDY_TODO_STATUSES = [
  "open",
  "in_progress",
  "blocked",
  "done",
  "cancelled",
];
export const AUTOMATION_SCHEDULE_KINDS = ["cron", "interval"];
export const AUTOMATION_JOB_KINDS = ["prompt", "sequence", "loop"];
export const AUTOMATION_RUN_STATUSES = [
  "claimed",
  "running",
  "complete",
  "failed",
  "cancelled",
];
export const BUDDY_RELATIONSHIP_KINDS = [
  "manager",
  "reports_to",
  "consults",
  "reviews",
];
export const BUDDY_SKILL_MODES = ["always", "on_demand"];
export const DELEGATION_STATUSES = ["pending", "active", "complete", "failed", "cancelled"];
export const REVIEW_STATUSES = ["draft", "complete", "cancelled"];
export const REVIEW_VERDICTS = ["needs_work", "pass", "fail"];
export const APPROVAL_STATUSES = ["pending", "approved", "rejected"];
export const AUTOMATION_ALLOWED_OPERATIONS = [
  "buddy.get_current_work",
  "buddy.get_inbox",
  "buddy.get_automations",
  "buddy.set_automation",
  "buddy.new_project",
  "buddy.update_project",
  "buddy.remember",
  "buddy.compact_memory",
  "buddy.delegate",
  "buddy.request_review",
  "buddy.complete_delegation",
  "buddy.complete_assignment",
  "buddy.submit_review",
  "buddy.request_human_approval",
];

const CURRENT_SCHEMA_VERSION = 11;
const DEFAULT_AUTOMATION_MAX_RUNTIME_SECONDS = 600;
const DEFAULT_AUTOMATION_MAX_ITERATIONS = 10;
const DEFAULT_AUTOMATION_MAX_TOKENS = 50_000;
const DEFAULT_AUTOMATION_MAX_COST_USD = 2;
const DEFAULT_AUTOMATION_ALLOWED_OPERATIONS = ["buddy.get_current_work"];

export function defaultDatabasePath() {
  const buddiesHome =
    process.env.BUDDIES_HOME?.trim() || join(homedir(), ".buddies");
  return join(resolve(buddiesHome), "buddies.sqlite");
}

function now() {
  return new Date().toISOString();
}

function id(prefix) {
  return `${prefix}_${randomUUID()}`;
}

function assertOneOf(label, value, allowed) {
  if (!allowed.includes(value)) {
    throw new Error(`${label} must be one of: ${allowed.join(", ")}`);
  }
}

function required(label, value) {
  if (typeof value !== "string" || value.trim() === "") {
    throw new Error(`${label} is required`);
  }
  return value.trim();
}

function slugify(value) {
  return required("name", value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

function rows(statement, ...params) {
  return statement.all(...params).map((row) => ({ ...row }));
}

export class BuddiesStore {
  constructor(databasePath = defaultDatabasePath()) {
    this.databasePath = databasePath === ":memory:" ? databasePath : resolve(databasePath);
    if (this.databasePath !== ":memory:") {
      mkdirSync(dirname(this.databasePath), { recursive: true });
    }
    this.db = new DatabaseSync(this.databasePath);
    this.db.exec("PRAGMA foreign_keys = ON");
    if (this.databasePath !== ":memory:") {
      this.db.exec("PRAGMA journal_mode = WAL");
    }
    this.#migrate();
  }

  close() {
    this.db.close();
  }

  backupDatabase(destination) {
    if (this.databasePath === ":memory:") {
      throw new Error("in-memory Buddy databases cannot be backed up");
    }
    const target = resolve(required("backup destination", destination));
    if (existsSync(target)) throw new Error(`backup destination already exists: ${target}`);
    mkdirSync(dirname(target), { recursive: true });
    this.db.prepare("VACUUM INTO ?").run(target);
    return {
      database: this.databasePath,
      backup: target,
      schemaVersion: this.db.prepare("PRAGMA user_version").get().user_version,
      createdAt: now(),
    };
  }

  #migrate() {
    let version = this.db.prepare("PRAGMA user_version").get().user_version;
    if (version > CURRENT_SCHEMA_VERSION) {
      throw new Error(
        `Database schema ${version} is newer than this Buddies version (${CURRENT_SCHEMA_VERSION})`,
      );
    }
    if (version === 0) {
      this.db.exec(`
        BEGIN;

        CREATE TABLE projects (
          id TEXT PRIMARY KEY,
          slug TEXT NOT NULL UNIQUE,
          name TEXT NOT NULL,
          root_path TEXT NOT NULL UNIQUE,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        ) STRICT;

        CREATE TABLE buddies (
          id TEXT PRIMARY KEY,
          project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          slug TEXT NOT NULL,
          name TEXT NOT NULL,
          role TEXT NOT NULL,
          status TEXT NOT NULL CHECK (status IN ('active', 'paused', 'archived')),
          soul_path TEXT,
          memory_path TEXT,
          provider TEXT,
          model TEXT,
          reasoning_effort TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          UNIQUE(project_id, slug)
        ) STRICT;

        CREATE TABLE buddy_projects (
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          assignment_role TEXT,
          created_at TEXT NOT NULL,
          PRIMARY KEY (buddy_id, project_id)
        ) STRICT;

        CREATE TABLE sprints (
          id TEXT PRIMARY KEY,
          project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          name TEXT NOT NULL,
          goal TEXT,
          status TEXT NOT NULL CHECK (status IN ('planned', 'active', 'completed', 'cancelled')),
          starts_at TEXT,
          ends_at TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        ) STRICT;

        CREATE UNIQUE INDEX one_active_sprint_per_project
          ON sprints(project_id) WHERE status = 'active';

        CREATE TABLE work_items (
          id TEXT PRIMARY KEY,
          project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          sprint_id TEXT REFERENCES sprints(id) ON DELETE SET NULL,
          buddy_id TEXT REFERENCES buddies(id) ON DELETE SET NULL,
          title TEXT NOT NULL,
          kind TEXT NOT NULL DEFAULT 'task',
          external_key TEXT,
          source_path TEXT,
          objective TEXT,
          definition_of_done TEXT NOT NULL,
          status TEXT NOT NULL CHECK (
            status IN ('backlog', 'ready', 'in_progress', 'blocked', 'review', 'done', 'cancelled')
          ),
          priority INTEGER NOT NULL DEFAULT 0,
          next_action TEXT,
          blocked_reason TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          completed_at TEXT
        ) STRICT;

        CREATE UNIQUE INDEX work_items_by_external_key
          ON work_items(project_id, external_key)
          WHERE external_key IS NOT NULL;

        CREATE INDEX work_items_by_project_status
          ON work_items(project_id, status, priority DESC, created_at);
        CREATE INDEX work_items_by_buddy_status
          ON work_items(buddy_id, status, priority DESC, created_at);

        CREATE TABLE conversation_links (
          id TEXT PRIMARY KEY,
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          work_item_id TEXT REFERENCES work_items(id) ON DELETE SET NULL,
          provider TEXT NOT NULL,
          provider_session_id TEXT,
          unleashd_conversation_id TEXT,
          status TEXT NOT NULL CHECK (status IN ('active', 'complete', 'failed', 'cancelled')),
          started_at TEXT NOT NULL,
          last_active_at TEXT NOT NULL,
          ended_at TEXT,
          CHECK (provider_session_id IS NOT NULL OR unleashd_conversation_id IS NOT NULL)
        ) STRICT;

        CREATE UNIQUE INDEX conversation_links_by_unleashd_id
          ON conversation_links(unleashd_conversation_id)
          WHERE unleashd_conversation_id IS NOT NULL;

        PRAGMA user_version = 3;
        COMMIT;
      `);
      version = 3;
    }
    if (version === 1) {
      this.db.exec(`
        BEGIN;
        CREATE TABLE buddy_projects (
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          assignment_role TEXT,
          created_at TEXT NOT NULL,
          PRIMARY KEY (buddy_id, project_id)
        ) STRICT;
        INSERT INTO buddy_projects (buddy_id, project_id, assignment_role, created_at)
          SELECT id, project_id, role, created_at FROM buddies;
        PRAGMA user_version = 2;
        COMMIT;
      `);
      version = 2;
    }
    if (version === 2) {
      this.db.exec(`
        BEGIN;
        ALTER TABLE work_items ADD COLUMN kind TEXT NOT NULL DEFAULT 'task';
        ALTER TABLE work_items ADD COLUMN external_key TEXT;
        ALTER TABLE work_items ADD COLUMN source_path TEXT;
        CREATE UNIQUE INDEX work_items_by_external_key
          ON work_items(project_id, external_key)
          WHERE external_key IS NOT NULL;
        PRAGMA user_version = 3;
        COMMIT;
      `);
      version = 3;
    }
    if (version === 3) {
      this.db.exec(`
        BEGIN;

        CREATE TABLE owned_projects (
          id TEXT PRIMARY KEY,
          workspace_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          sprint_id TEXT REFERENCES sprints(id) ON DELETE SET NULL,
          title TEXT NOT NULL,
          objective TEXT,
          definition_of_done TEXT NOT NULL,
          status TEXT NOT NULL CHECK (
            status IN ('backlog', 'ready', 'in_progress', 'blocked', 'review', 'done', 'cancelled')
          ),
          priority INTEGER NOT NULL DEFAULT 0,
          next_action TEXT,
          blocked_reason TEXT,
          source_path TEXT,
          external_key TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          completed_at TEXT
        ) STRICT;

        CREATE UNIQUE INDEX owned_projects_by_external_key
          ON owned_projects(workspace_id, external_key)
          WHERE external_key IS NOT NULL;
        CREATE INDEX owned_projects_by_buddy_status
          ON owned_projects(buddy_id, status, priority DESC, created_at);

        CREATE TABLE buddy_todos (
          id TEXT PRIMARY KEY,
          buddy_project_id TEXT NOT NULL REFERENCES owned_projects(id) ON DELETE CASCADE,
          title TEXT NOT NULL,
          status TEXT NOT NULL CHECK (
            status IN ('open', 'in_progress', 'blocked', 'done', 'cancelled')
          ),
          position INTEGER NOT NULL,
          definition_of_done TEXT,
          next_action TEXT,
          blocked_reason TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          completed_at TEXT
        ) STRICT;
        CREATE INDEX buddy_todos_by_project_position
          ON buddy_todos(buddy_project_id, position, created_at);

        CREATE TABLE buddy_automations (
          id TEXT PRIMARY KEY,
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          workspace_id TEXT REFERENCES projects(id) ON DELETE CASCADE,
          buddy_project_id TEXT REFERENCES owned_projects(id) ON DELETE CASCADE,
          name TEXT NOT NULL,
          schedule_kind TEXT NOT NULL CHECK (schedule_kind IN ('cron', 'interval')),
          schedule_expression TEXT NOT NULL,
          timezone TEXT NOT NULL,
          job_kind TEXT NOT NULL CHECK (job_kind IN ('prompt', 'sequence', 'loop')),
          job_payload TEXT NOT NULL,
          enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
          next_run_at TEXT,
          last_run_at TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        ) STRICT;
        CREATE INDEX buddy_automations_due
          ON buddy_automations(enabled, next_run_at);

        CREATE TABLE buddy_automation_runs (
          id TEXT PRIMARY KEY,
          automation_id TEXT NOT NULL REFERENCES buddy_automations(id) ON DELETE CASCADE,
          scheduled_for TEXT NOT NULL,
          idempotency_key TEXT NOT NULL UNIQUE,
          status TEXT NOT NULL CHECK (
            status IN ('claimed', 'running', 'complete', 'failed', 'cancelled')
          ),
          conversation_id TEXT,
          iteration INTEGER NOT NULL DEFAULT 0,
          outcome TEXT,
          error TEXT,
          claimed_at TEXT NOT NULL,
          started_at TEXT,
          ended_at TEXT
        ) STRICT;
        CREATE INDEX buddy_automation_runs_by_automation
          ON buddy_automation_runs(automation_id, claimed_at DESC);

        ALTER TABLE conversation_links
          ADD COLUMN buddy_project_id TEXT REFERENCES owned_projects(id) ON DELETE SET NULL;

        PRAGMA user_version = 4;
        COMMIT;
      `);
      version = 4;
    }
    if (version === 4) {
      this.db.exec(`
        BEGIN;

        ALTER TABLE conversation_links
          ADD COLUMN workspace_id TEXT REFERENCES projects(id) ON DELETE CASCADE;
        UPDATE conversation_links
        SET workspace_id = COALESCE(
          (SELECT workspace_id FROM owned_projects
            WHERE owned_projects.id = conversation_links.buddy_project_id),
          (SELECT project_id FROM work_items
            WHERE work_items.id = conversation_links.work_item_id),
          (SELECT project_id FROM buddies
            WHERE buddies.id = conversation_links.buddy_id)
        );

        CREATE TABLE buddy_relationships (
          id TEXT PRIMARY KEY,
          from_buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          to_buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          kind TEXT NOT NULL CHECK (
            kind IN ('manager', 'reports_to', 'consults', 'reviews')
          ),
          created_at TEXT NOT NULL,
          UNIQUE(from_buddy_id, to_buddy_id, kind),
          CHECK(from_buddy_id != to_buddy_id)
        ) STRICT;

        CREATE TABLE buddy_skills (
          id TEXT PRIMARY KEY,
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          name TEXT NOT NULL,
          instruction_path TEXT NOT NULL,
          mode TEXT NOT NULL CHECK (mode IN ('always', 'on_demand')),
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          UNIQUE(buddy_id, name)
        ) STRICT;

        CREATE TABLE buddy_delegations (
          id TEXT PRIMARY KEY,
          from_buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          to_buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          workspace_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          buddy_project_id TEXT REFERENCES owned_projects(id) ON DELETE SET NULL,
          purpose TEXT NOT NULL,
          parent_conversation_id TEXT,
          child_conversation_id TEXT,
          status TEXT NOT NULL CHECK (
            status IN ('pending', 'active', 'complete', 'failed', 'cancelled')
          ),
          outcome TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          completed_at TEXT,
          CHECK(from_buddy_id != to_buddy_id)
        ) STRICT;

        CREATE TABLE buddy_reviews (
          id TEXT PRIMARY KEY,
          reviewer_buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          subject_buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          workspace_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          buddy_project_id TEXT REFERENCES owned_projects(id) ON DELETE SET NULL,
          conversation_id TEXT,
          status TEXT NOT NULL CHECK (status IN ('draft', 'complete', 'cancelled')),
          verdict TEXT CHECK (verdict IN ('needs_work', 'pass', 'fail')),
          score REAL,
          summary TEXT,
          evidence TEXT NOT NULL DEFAULT '[]',
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          completed_at TEXT
        ) STRICT;

        PRAGMA user_version = 5;
        COMMIT;
      `);
      version = 5;
    }
    if (version === 5) {
      this.db.exec(`
        BEGIN;

        UPDATE conversation_links
        SET workspace_id = (
          SELECT project_id FROM buddies
          WHERE buddies.id = conversation_links.buddy_id
        )
        WHERE workspace_id IS NULL;

        UPDATE buddy_automations
        SET workspace_id = (
          SELECT project_id FROM buddies
          WHERE buddies.id = buddy_automations.buddy_id
        )
        WHERE workspace_id IS NULL;

        CREATE TRIGGER conversation_links_workspace_required_insert
        BEFORE INSERT ON conversation_links
        WHEN NEW.workspace_id IS NULL
        BEGIN
          SELECT RAISE(ABORT, 'conversation workspace is required');
        END;

        CREATE TRIGGER conversation_links_workspace_required_update
        BEFORE UPDATE OF workspace_id ON conversation_links
        WHEN NEW.workspace_id IS NULL
        BEGIN
          SELECT RAISE(ABORT, 'conversation workspace is required');
        END;

        CREATE TRIGGER buddy_automations_workspace_required_insert
        BEFORE INSERT ON buddy_automations
        WHEN NEW.workspace_id IS NULL
        BEGIN
          SELECT RAISE(ABORT, 'automation workspace is required');
        END;

        CREATE TRIGGER buddy_automations_workspace_required_update
        BEFORE UPDATE OF workspace_id ON buddy_automations
        WHEN NEW.workspace_id IS NULL
        BEGIN
          SELECT RAISE(ABORT, 'automation workspace is required');
        END;

        PRAGMA user_version = 6;
        COMMIT;
      `);
      version = 6;
    }
    if (version === 6) {
      this.db.exec(`
        BEGIN;

        CREATE TABLE buddy_audit_events (
          id TEXT PRIMARY KEY,
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          workspace_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          buddy_project_id TEXT REFERENCES owned_projects(id) ON DELETE SET NULL,
          operation TEXT NOT NULL,
          payload TEXT NOT NULL,
          created_at TEXT NOT NULL
        ) STRICT;
        CREATE INDEX buddy_audit_events_by_buddy
          ON buddy_audit_events(buddy_id, created_at DESC);
        CREATE INDEX buddy_audit_events_by_project
          ON buddy_audit_events(buddy_project_id, created_at DESC);

        PRAGMA user_version = 7;
        COMMIT;
      `);
      version = 7;
    }
    if (version === 7) {
      this.db.exec(`
        BEGIN;

        CREATE TABLE buddy_automation_policies (
          automation_id TEXT PRIMARY KEY
            REFERENCES buddy_automations(id) ON DELETE CASCADE,
          max_runtime_seconds INTEGER NOT NULL CHECK (max_runtime_seconds > 0),
          max_iterations INTEGER NOT NULL CHECK (max_iterations > 0),
          max_tokens INTEGER NOT NULL CHECK (max_tokens > 0),
          max_cost_usd REAL NOT NULL CHECK (max_cost_usd > 0),
          allowed_operations TEXT NOT NULL CHECK (
            json_valid(allowed_operations) AND json_type(allowed_operations) = 'array'
          ),
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        ) STRICT;

        INSERT INTO buddy_automation_policies (
          automation_id, max_runtime_seconds, max_iterations, max_tokens,
          max_cost_usd, allowed_operations, created_at, updated_at
        )
        SELECT
          id,
          600,
          CASE job_kind
            WHEN 'prompt' THEN 1
            WHEN 'sequence' THEN
              MIN(10, MAX(1, json_array_length(json_extract(job_payload, '$.prompts'))))
            WHEN 'loop' THEN
              MIN(10, MAX(1, CAST(json_extract(job_payload, '$.termination.max_iterations') AS INTEGER)))
          END,
          50000,
          2.0,
          '["buddy.get_current_work"]',
          created_at,
          updated_at
        FROM buddy_automations;

        CREATE TABLE buddy_automation_run_policies (
          run_id TEXT PRIMARY KEY
            REFERENCES buddy_automation_runs(id) ON DELETE CASCADE,
          max_runtime_seconds INTEGER NOT NULL CHECK (max_runtime_seconds > 0),
          max_iterations INTEGER NOT NULL CHECK (max_iterations > 0),
          max_tokens INTEGER NOT NULL CHECK (max_tokens > 0),
          max_cost_usd REAL NOT NULL CHECK (max_cost_usd > 0),
          allowed_operations TEXT NOT NULL CHECK (
            json_valid(allowed_operations) AND json_type(allowed_operations) = 'array'
          ),
          tokens_used INTEGER NOT NULL DEFAULT 0 CHECK (tokens_used >= 0),
          cost_usd REAL NOT NULL DEFAULT 0 CHECK (cost_usd >= 0)
        ) STRICT;

        INSERT INTO buddy_automation_run_policies (
          run_id, max_runtime_seconds, max_iterations, max_tokens,
          max_cost_usd, allowed_operations, tokens_used, cost_usd
        )
        SELECT
          runs.id, policies.max_runtime_seconds, policies.max_iterations,
          policies.max_tokens, policies.max_cost_usd, policies.allowed_operations,
          0, 0
        FROM buddy_automation_runs AS runs
        JOIN buddy_automation_policies AS policies
          ON policies.automation_id = runs.automation_id;

        CREATE TABLE buddy_approval_requests (
          id TEXT PRIMARY KEY,
          buddy_id TEXT NOT NULL REFERENCES buddies(id) ON DELETE CASCADE,
          workspace_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          buddy_project_id TEXT REFERENCES owned_projects(id) ON DELETE SET NULL,
          automation_run_id TEXT REFERENCES buddy_automation_runs(id) ON DELETE SET NULL,
          conversation_id TEXT,
          action TEXT NOT NULL,
          reason TEXT NOT NULL,
          risk TEXT NOT NULL,
          status TEXT NOT NULL CHECK (status IN ('pending', 'approved', 'rejected')),
          resolved_by TEXT,
          resolution_note TEXT,
          requested_at TEXT NOT NULL,
          resolved_at TEXT,
          CHECK (
            (status = 'pending' AND resolved_by IS NULL AND resolved_at IS NULL)
            OR
            (status IN ('approved', 'rejected') AND resolved_by IS NOT NULL AND resolved_at IS NOT NULL)
          )
        ) STRICT;
        CREATE INDEX buddy_approval_requests_by_buddy
          ON buddy_approval_requests(buddy_id, status, requested_at DESC);
        CREATE INDEX buddy_approval_requests_by_workspace
          ON buddy_approval_requests(workspace_id, status, requested_at DESC);

        PRAGMA user_version = 8;
        COMMIT;
      `);
      version = 8;
    }
    if (version === 8) {
      const runColumns = new Set(
        rows(this.db.prepare("PRAGMA table_info(buddy_automation_runs)")).map(
          (column) => column.name,
        ),
      );
      this.db.exec("BEGIN");
      try {
        if (!runColumns.has("claim_token")) {
          this.db.exec("ALTER TABLE buddy_automation_runs ADD COLUMN claim_token TEXT");
        }
        if (!runColumns.has("claim_expires_at")) {
          this.db.exec(
            "ALTER TABLE buddy_automation_runs ADD COLUMN claim_expires_at TEXT",
          );
        }
        this.db.exec(`
          CREATE INDEX IF NOT EXISTS buddy_automation_runs_by_claim_expiry
            ON buddy_automation_runs(status, claim_expires_at);
          PRAGMA user_version = 9;
          COMMIT;
        `);
      } catch (error) {
        this.db.exec("ROLLBACK");
        throw error;
      }
      version = 9;
    }
    if (version === 9) {
      const delegationColumns = new Set(
        rows(this.db.prepare("PRAGMA table_info(buddy_delegations)")).map(
          (column) => column.name,
        ),
      );
      this.db.exec("BEGIN");
      try {
        if (!delegationColumns.has("dispatch_token")) {
          this.db.exec("ALTER TABLE buddy_delegations ADD COLUMN dispatch_token TEXT");
        }
        if (!delegationColumns.has("dispatch_expires_at")) {
          this.db.exec(
            "ALTER TABLE buddy_delegations ADD COLUMN dispatch_expires_at TEXT",
          );
        }
        this.db.exec(`
          CREATE INDEX IF NOT EXISTS buddy_delegations_by_dispatch_expiry
            ON buddy_delegations(status, dispatch_expires_at);
          PRAGMA user_version = 10;
          COMMIT;
        `);
      } catch (error) {
        this.db.exec("ROLLBACK");
        throw error;
      }
      version = 10;
    }
    if (version === 10) {
      this.db.exec(`
        BEGIN;

        CREATE TABLE IF NOT EXISTS buddy_builder_creations (
          conversation_id TEXT PRIMARY KEY,
          buddy_id TEXT NOT NULL UNIQUE REFERENCES buddies(id) ON DELETE CASCADE,
          workspace_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
          request_fingerprint TEXT NOT NULL,
          created_at TEXT NOT NULL
        ) STRICT;

        PRAGMA user_version = 11;
        COMMIT;
      `);
      version = 11;
    }
  }

  createProject({ name, rootPath, slug = slugify(name) }) {
    const timestamp = now();
    const project = {
      id: id("project"),
      slug: required("project slug", slug),
      name: required("project name", name),
      rootPath: resolve(required("project root path", rootPath)),
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    this.db
      .prepare(`
        INSERT INTO projects (id, slug, name, root_path, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?)
      `)
      .run(
        project.id,
        project.slug,
        project.name,
        project.rootPath,
        project.createdAt,
        project.updatedAt,
      );
    return this.getProject(project.id);
  }

  getProject(idOrSlug) {
    const row = this.db
      .prepare("SELECT * FROM projects WHERE id = ? OR slug = ?")
      .get(idOrSlug, idOrSlug);
    return row ? { ...row } : null;
  }

  listProjects() {
    return rows(this.db.prepare("SELECT * FROM projects ORDER BY name"));
  }

  createWorkspace(input) {
    return this.createProject(input);
  }

  getWorkspace(idOrSlug) {
    return this.getProject(idOrSlug);
  }

  listWorkspaces() {
    return this.listProjects();
  }

  createBuddy({
    project,
    name,
    role,
    slug = slugify(name),
    status = "active",
    soulPath,
    memoryPath,
    provider,
    model,
    reasoningEffort,
  }) {
    assertOneOf("buddy status", status, BUDDY_STATUSES);
    const ownerProject = this.#requireProject(project);
    const timestamp = now();
    const buddy = {
      id: id("buddy"),
      projectId: ownerProject.id,
      slug: required("buddy slug", slug),
      name: required("buddy name", name),
      role: required("buddy role", role),
      status,
      soulPath: soulPath ? this.#projectPath(ownerProject, soulPath) : null,
      memoryPath: memoryPath ? this.#projectPath(ownerProject, memoryPath) : null,
      provider: provider || null,
      model: model || null,
      reasoningEffort: reasoningEffort || null,
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    try {
      this.db.exec("BEGIN");
      this.db
        .prepare(`
          INSERT INTO buddies (
            id, project_id, slug, name, role, status, soul_path, memory_path,
            provider, model, reasoning_effort, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `)
        .run(
          buddy.id,
          buddy.projectId,
          buddy.slug,
          buddy.name,
          buddy.role,
          buddy.status,
          buddy.soulPath,
          buddy.memoryPath,
          buddy.provider,
          buddy.model,
          buddy.reasoningEffort,
          buddy.createdAt,
          buddy.updatedAt,
        );
      this.db
        .prepare(`
          INSERT INTO buddy_projects (buddy_id, project_id, assignment_role, created_at)
          VALUES (?, ?, ?, ?)
        `)
        .run(buddy.id, buddy.projectId, buddy.role, timestamp);
      this.db.exec("COMMIT");
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
    return this.getBuddy(buddy.id);
  }

  /**
   * One transaction owns Builder idempotency, identity, and every workspace
   * assignment. Application code should not rebuild this with lookup/create
   * sequences: those can race across MCP processes.
   */
  createBuddyFromBuilder({
    conversationId,
    requestFingerprint,
    project,
    additionalWorkspaces = [],
    name,
    role,
    slug = slugify(name),
    status = "active",
    provider,
    model,
    reasoningEffort,
  }) {
    const builderConversationId = required("Builder conversation", conversationId);
    const fingerprint = required("Builder request fingerprint", requestFingerprint);
    const existing = this.db
      .prepare("SELECT * FROM buddy_builder_creations WHERE conversation_id = ?")
      .get(builderConversationId);
    if (existing) {
      if (existing.request_fingerprint !== fingerprint) {
        throw new Error("this Buddy Builder conversation already created a different Buddy");
      }
      const buddy = this.getBuddy(existing.buddy_id);
      if (!buddy) throw new Error("Buddy Builder result references a missing Buddy");
      return {
        buddy,
        homeWorkspace: this.getWorkspace(existing.workspace_id),
        workspaces: this.listBuddyWorkspaces(buddy.id),
        requestFingerprint: existing.request_fingerprint,
        replayed: true,
      };
    }

    assertOneOf("buddy status", status, BUDDY_STATUSES);
    const homeWorkspace = this.#requireProject(project);
    const assignedWorkspaces = [
      homeWorkspace,
      ...additionalWorkspaces.map((workspace) => this.#requireProject(workspace)),
    ].filter(
      (workspace, index, all) =>
        all.findIndex((candidate) => candidate.id === workspace.id) === index,
    );
    const timestamp = now();
    const buddy = {
      id: id("buddy"),
      projectId: homeWorkspace.id,
      slug: required("buddy slug", slug),
      name: required("buddy name", name),
      role: required("buddy role", role),
      status,
      soulPath: null,
      memoryPath: null,
      provider: provider || null,
      model: model || null,
      reasoningEffort: reasoningEffort || null,
      createdAt: timestamp,
      updatedAt: timestamp,
    };

    this.db.exec("BEGIN IMMEDIATE");
    try {
      this.db
        .prepare(`
          INSERT INTO buddies (
            id, project_id, slug, name, role, status, soul_path, memory_path,
            provider, model, reasoning_effort, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `)
        .run(
          buddy.id,
          buddy.projectId,
          buddy.slug,
          buddy.name,
          buddy.role,
          buddy.status,
          buddy.soulPath,
          buddy.memoryPath,
          buddy.provider,
          buddy.model,
          buddy.reasoningEffort,
          buddy.createdAt,
          buddy.updatedAt,
        );
      const assign = this.db.prepare(`
        INSERT INTO buddy_projects (buddy_id, project_id, assignment_role, created_at)
        VALUES (?, ?, ?, ?)
      `);
      for (const workspace of assignedWorkspaces) {
        assign.run(buddy.id, workspace.id, buddy.role, timestamp);
      }
      this.db
        .prepare(`
          INSERT INTO buddy_builder_creations (
            conversation_id, buddy_id, workspace_id, request_fingerprint, created_at
          ) VALUES (?, ?, ?, ?, ?)
        `)
        .run(builderConversationId, buddy.id, homeWorkspace.id, fingerprint, timestamp);
      this.db.exec("COMMIT");
    } catch (error) {
      this.db.exec("ROLLBACK");
      const raced = this.db
        .prepare("SELECT * FROM buddy_builder_creations WHERE conversation_id = ?")
        .get(builderConversationId);
      if (raced?.request_fingerprint === fingerprint) {
        const replayedBuddy = this.getBuddy(raced.buddy_id);
        if (!replayedBuddy) throw error;
        return {
          buddy: replayedBuddy,
          homeWorkspace: this.getWorkspace(raced.workspace_id),
          workspaces: this.listBuddyWorkspaces(replayedBuddy.id),
          requestFingerprint: raced.request_fingerprint,
          replayed: true,
        };
      }
      throw error;
    }
    return {
      buddy: this.getBuddy(buddy.id),
      homeWorkspace,
      workspaces: this.listBuddyWorkspaces(buddy.id),
      requestFingerprint: fingerprint,
      replayed: false,
    };
  }

  getBuddyBuilderResult(conversationId) {
    const creation = this.db
      .prepare("SELECT * FROM buddy_builder_creations WHERE conversation_id = ?")
      .get(required("Builder conversation", conversationId));
    if (!creation) return null;
    const buddy = this.getBuddy(creation.buddy_id);
    if (!buddy) return null;
    return {
      buddy,
      homeWorkspace: this.getWorkspace(creation.workspace_id),
      workspaces: this.listBuddyWorkspaces(buddy.id),
      requestFingerprint: creation.request_fingerprint,
      replayed: true,
    };
  }

  getBuddy(idOrSlug, project) {
    let row;
    if (project) {
      const ownerProject = this.#requireProject(project);
      row = this.db
        .prepare(`
          SELECT buddies.*
          FROM buddies
          JOIN buddy_projects ON buddy_projects.buddy_id = buddies.id
          WHERE buddy_projects.project_id = ? AND (buddies.id = ? OR buddies.slug = ?)
        `)
        .get(ownerProject.id, idOrSlug, idOrSlug);
    } else {
      row = this.db.prepare("SELECT * FROM buddies WHERE id = ?").get(idOrSlug);
      if (!row) {
        const matches = rows(
          this.db.prepare("SELECT * FROM buddies WHERE slug = ? ORDER BY project_id"),
          idOrSlug,
        );
        if (matches.length > 1) {
          throw new Error(
            `buddy slug is ambiguous across workspaces: ${idOrSlug}; use the Buddy id or provide a workspace`,
          );
        }
        row = matches[0];
      }
    }
    return row ? { ...row } : null;
  }

  updateBuddy(buddy, {
    name,
    role,
    status,
    homeWorkspace,
    soulPath,
    memoryPath,
    provider,
    model,
    reasoningEffort,
  } = {}) {
    const current = this.#requireBuddy(buddy);
    const workspace =
      homeWorkspace === undefined
        ? this.#requireProject(current.project_id)
        : this.#requireProject(homeWorkspace);
    const nextStatus = status ?? current.status;
    assertOneOf("buddy status", nextStatus, BUDDY_STATUSES);
    const nextSoulPath =
      soulPath === undefined
        ? homeWorkspace === undefined || !current.soul_path
          ? current.soul_path
          : this.#projectPath(workspace, current.soul_path)
        : soulPath
          ? this.#projectPath(workspace, soulPath)
          : null;
    const nextMemoryPath =
      memoryPath === undefined
        ? homeWorkspace === undefined || !current.memory_path
          ? current.memory_path
          : this.#projectPath(workspace, current.memory_path)
        : memoryPath
          ? this.#projectPath(workspace, memoryPath)
          : null;
    const timestamp = now();
    try {
      this.db.exec("BEGIN");
      this.db
        .prepare(`
          UPDATE buddies SET
            project_id = ?, name = ?, role = ?, status = ?, soul_path = ?, memory_path = ?,
            provider = ?, model = ?, reasoning_effort = ?, updated_at = ?
          WHERE id = ?
        `)
        .run(
          workspace.id,
          name === undefined ? current.name : required("buddy name", name),
          role === undefined ? current.role : required("buddy role", role),
          nextStatus,
          nextSoulPath,
          nextMemoryPath,
          provider === undefined ? current.provider : provider || null,
          model === undefined ? current.model : model || null,
          reasoningEffort === undefined
            ? current.reasoning_effort
            : reasoningEffort || null,
          timestamp,
          current.id,
        );
      this.db
        .prepare(`
          INSERT INTO buddy_projects (buddy_id, project_id, assignment_role, created_at)
          VALUES (?, ?, ?, ?)
          ON CONFLICT(buddy_id, project_id) DO NOTHING
        `)
        .run(current.id, workspace.id, role ?? current.role, timestamp);
      this.db.exec("COMMIT");
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
    return this.getBuddy(current.id);
  }

  listBuddies(project) {
    if (!project) {
      return rows(
        this.db.prepare(`
          SELECT buddies.*, projects.slug AS project_slug
          FROM buddies
          JOIN projects ON projects.id = buddies.project_id
          ORDER BY projects.name, buddies.name
        `),
      );
    }
    const ownerProject = this.#requireProject(project);
    return rows(
      this.db.prepare(`
        SELECT buddies.*, buddy_projects.assignment_role
        FROM buddies
        JOIN buddy_projects ON buddy_projects.buddy_id = buddies.id
        WHERE buddy_projects.project_id = ?
        ORDER BY buddies.name
      `),
      ownerProject.id,
    );
  }

  assignBuddyToProject({ buddy, project, role }) {
    const ownerBuddy = this.#requireBuddy(buddy);
    const ownerProject = this.#requireProject(project);
    this.db
      .prepare(`
        INSERT INTO buddy_projects (buddy_id, project_id, assignment_role, created_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(buddy_id, project_id) DO UPDATE SET
          assignment_role = excluded.assignment_role
      `)
      .run(ownerBuddy.id, ownerProject.id, role?.trim() || ownerBuddy.role, now());
    return this.listBuddyProjects(ownerBuddy.id);
  }

  listBuddyProjects(buddy) {
    const ownerBuddy = this.#requireBuddy(buddy);
    return rows(
      this.db.prepare(`
        SELECT projects.*, buddy_projects.assignment_role
        FROM buddy_projects
        JOIN projects ON projects.id = buddy_projects.project_id
        WHERE buddy_projects.buddy_id = ?
        ORDER BY projects.name
      `),
      ownerBuddy.id,
    );
  }

  assignBuddyToWorkspace({ buddy, workspace, role }) {
    return this.assignBuddyToProject({ buddy, project: workspace, role });
  }

  listBuddyWorkspaces(buddy) {
    return this.listBuddyProjects(buddy);
  }

  setBuddyRelationship({ fromBuddy, toBuddy, kind }) {
    assertOneOf("relationship kind", kind, BUDDY_RELATIONSHIP_KINDS);
    const from = this.#requireBuddy(fromBuddy);
    const to = this.#requireBuddy(toBuddy);
    if (from.id === to.id) throw new Error("a Buddy cannot relate to itself");
    const relationshipId = id("relationship");
    this.db
      .prepare(`
        INSERT INTO buddy_relationships (
          id, from_buddy_id, to_buddy_id, kind, created_at
        ) VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(from_buddy_id, to_buddy_id, kind) DO NOTHING
      `)
      .run(relationshipId, from.id, to.id, kind, now());
    return this.db
      .prepare(`
        SELECT * FROM buddy_relationships
        WHERE from_buddy_id = ? AND to_buddy_id = ? AND kind = ?
      `)
      .get(from.id, to.id, kind);
  }

  removeBuddyRelationship(relationship) {
    const result = this.db
      .prepare("DELETE FROM buddy_relationships WHERE id = ?")
      .run(required("relationship", relationship));
    return result.changes > 0;
  }

  listBuddyRelationships(buddy) {
    const ownerBuddy = this.#requireBuddy(buddy);
    return rows(
      this.db.prepare(`
        SELECT buddy_relationships.*,
          from_buddy.name AS from_buddy_name, to_buddy.name AS to_buddy_name
        FROM buddy_relationships
        JOIN buddies AS from_buddy ON from_buddy.id = from_buddy_id
        JOIN buddies AS to_buddy ON to_buddy.id = to_buddy_id
        WHERE from_buddy_id = ? OR to_buddy_id = ?
        ORDER BY created_at
      `),
      ownerBuddy.id,
      ownerBuddy.id,
    );
  }

  recordAuditEvent({ buddy, workspace, project, operation, payload = {} }) {
    const ownerWorkspace = this.#requireProject(workspace);
    const ownerBuddy = this.#requireBuddy(buddy, ownerWorkspace);
    const ownerProject = project ? this.#requireBuddyProject(project) : null;
    if (ownerProject && ownerProject.workspace_id !== ownerWorkspace.id) {
      throw new Error("audit project does not belong to the workspace");
    }
    const event = {
      id: id("audit"),
      buddyId: ownerBuddy.id,
      workspaceId: ownerWorkspace.id,
      buddyProjectId: ownerProject?.id || null,
      operation: required("audit operation", operation),
      payload: JSON.stringify(payload ?? {}),
      createdAt: now(),
    };
    this.db
      .prepare(`
        INSERT INTO buddy_audit_events (
          id, buddy_id, workspace_id, buddy_project_id,
          operation, payload, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        event.id,
        event.buddyId,
        event.workspaceId,
        event.buddyProjectId,
        event.operation,
        event.payload,
        event.createdAt,
      );
    return this.getAuditEvent(event.id);
  }

  getAuditEvent(event) {
    const row = this.db
      .prepare("SELECT * FROM buddy_audit_events WHERE id = ?")
      .get(required("audit event", event));
    return row
      ? {
          ...row,
          payload: JSON.parse(row.payload),
        }
      : null;
  }

  listAuditEvents({ buddy, workspace, project, limit = 100 } = {}) {
    const conditions = [];
    const params = [];
    if (buddy) {
      conditions.push("buddy_id = ?");
      params.push(this.#requireBuddy(buddy).id);
    }
    if (workspace) {
      conditions.push("workspace_id = ?");
      params.push(this.#requireProject(workspace).id);
    }
    if (project) {
      conditions.push("buddy_project_id = ?");
      params.push(this.#requireBuddyProject(project).id);
    }
    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const safeLimit = Math.max(1, Math.min(1000, Number(limit) || 100));
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_audit_events
        ${where}
        ORDER BY created_at DESC, id DESC
        LIMIT ?
      `),
      ...params,
      safeLimit,
    ).map((row) => ({
      ...row,
      payload: JSON.parse(row.payload),
    }));
  }

  createApprovalRequest({
    buddy,
    workspace,
    project,
    automationRun,
    conversationId,
    action,
    reason,
    risk,
  }) {
    const ownerWorkspace = this.#requireProject(workspace);
    const ownerBuddy = this.#requireBuddy(buddy, ownerWorkspace);
    const ownerRun = automationRun ? this.#requireAutomationRun(automationRun) : null;
    const runAutomation = ownerRun ? this.#requireAutomation(ownerRun.automation_id) : null;
    const ownerProject = project
      ? this.#requireBuddyProject(project)
      : runAutomation?.buddy_project_id
        ? this.#requireBuddyProject(runAutomation.buddy_project_id)
        : null;
    if (ownerProject && ownerProject.workspace_id !== ownerWorkspace.id) {
      throw new Error("approval project does not belong to the workspace");
    }
    if (ownerProject && ownerProject.buddy_id !== ownerBuddy.id) {
      throw new Error("approval project does not belong to the Buddy");
    }
    if (ownerRun) {
      if (
        runAutomation.buddy_id !== ownerBuddy.id ||
        runAutomation.workspace_id !== ownerWorkspace.id ||
        (ownerProject && runAutomation.buddy_project_id !== ownerProject.id)
      ) {
        throw new Error("automation run does not belong to the approval scope");
      }
    }
    const conversation = conversationId
      ? this.db
          .prepare(`
            SELECT * FROM conversation_links
            WHERE id = ? OR unleashd_conversation_id = ? OR provider_session_id = ?
          `)
          .get(conversationId, conversationId, conversationId)
      : null;
    if (conversationId && !conversation) {
      throw new Error("approval conversation is not linked to the Buddy");
    }
    if (
      conversation &&
      (conversation.buddy_id !== ownerBuddy.id ||
        conversation.workspace_id !== ownerWorkspace.id ||
        (ownerProject && conversation.buddy_project_id !== ownerProject.id))
    ) {
      throw new Error("conversation does not belong to the approval scope");
    }
    const approvalId = id("approval");
    const timestamp = now();
    const request = {
      id: approvalId,
      buddyId: ownerBuddy.id,
      workspaceId: ownerWorkspace.id,
      buddyProjectId: ownerProject?.id || null,
      automationRunId: ownerRun?.id || null,
      conversationId: conversationId?.trim() || null,
      action: required("approval action", action),
      reason: required("approval reason", reason),
      risk: required("approval risk", risk),
      requestedAt: timestamp,
    };
    try {
      this.db.exec("BEGIN");
      this.db
        .prepare(`
          INSERT INTO buddy_approval_requests (
            id, buddy_id, workspace_id, buddy_project_id, automation_run_id,
            conversation_id, action, reason, risk, status, resolved_by,
            resolution_note, requested_at, resolved_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', NULL, NULL, ?, NULL)
        `)
        .run(
          request.id,
          request.buddyId,
          request.workspaceId,
          request.buddyProjectId,
          request.automationRunId,
          request.conversationId,
          request.action,
          request.reason,
          request.risk,
          request.requestedAt,
        );
      this.recordAuditEvent({
        buddy: ownerBuddy.id,
        workspace: ownerWorkspace.id,
        project: ownerProject?.id,
        operation: "buddy.request_human_approval",
        payload: {
          approvalId,
          automationRunId: request.automationRunId,
          conversationId: request.conversationId,
          action: request.action,
          reason: request.reason,
          risk: request.risk,
          status: "pending",
        },
      });
      this.db.exec("COMMIT");
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
    return this.getApprovalRequest(approvalId);
  }

  getApprovalRequest(approval) {
    const row = this.db
      .prepare("SELECT * FROM buddy_approval_requests WHERE id = ?")
      .get(required("approval request", approval));
    return row ? { ...row } : null;
  }

  listApprovalRequests({ buddy, workspace, project, status, limit = 100 } = {}) {
    const conditions = [];
    const params = [];
    if (buddy) {
      conditions.push("buddy_id = ?");
      params.push(this.#requireBuddy(buddy).id);
    }
    if (workspace) {
      conditions.push("workspace_id = ?");
      params.push(this.#requireProject(workspace).id);
    }
    if (project) {
      conditions.push("buddy_project_id = ?");
      params.push(this.#requireBuddyProject(project).id);
    }
    if (status) {
      assertOneOf("approval status", status, APPROVAL_STATUSES);
      conditions.push("status = ?");
      params.push(status);
    }
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_approval_requests
        ${conditions.length ? `WHERE ${conditions.join(" AND ")}` : ""}
        ORDER BY requested_at DESC, id DESC
        LIMIT ?
      `),
      ...params,
      Math.max(1, Math.min(1000, Number(limit) || 100)),
    );
  }

  resolveApprovalRequest(approval, { decision, resolvedBy, note } = {}) {
    assertOneOf("approval decision", decision, ["approved", "rejected"]);
    const current = this.getApprovalRequest(approval);
    if (!current) throw new Error(`approval request not found: ${approval}`);
    if (current.status !== "pending") {
      throw new Error(`approval request is already ${current.status}`);
    }
    const actor = required("approval resolver", resolvedBy);
    const timestamp = now();
    try {
      this.db.exec("BEGIN IMMEDIATE");
      const result = this.db
        .prepare(`
          UPDATE buddy_approval_requests
          SET status = ?, resolved_by = ?, resolution_note = ?, resolved_at = ?
          WHERE id = ? AND status = 'pending'
        `)
        .run(decision, actor, note?.trim() || null, timestamp, current.id);
      if (result.changes !== 1) {
        throw new Error("approval request was resolved concurrently");
      }
      this.recordAuditEvent({
        buddy: current.buddy_id,
        workspace: current.workspace_id,
        project: current.buddy_project_id || undefined,
        operation: "buddy.resolve_human_approval",
        payload: {
          approvalId: current.id,
          decision,
          resolvedBy: actor,
          note: note?.trim() || null,
        },
      });
      this.db.exec("COMMIT");
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
    return this.getApprovalRequest(current.id);
  }

  assignBuddySkill({ buddy, name, instructionPath, mode = "on_demand" }) {
    assertOneOf("skill mode", mode, BUDDY_SKILL_MODES);
    const ownerBuddy = this.#requireBuddy(buddy);
    const rootWorkspace = this.#requireProject(ownerBuddy.project_id);
    const path = this.#projectPath(rootWorkspace, instructionPath);
    const timestamp = now();
    this.db
      .prepare(`
        INSERT INTO buddy_skills (
          id, buddy_id, name, instruction_path, mode, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(buddy_id, name) DO UPDATE SET
          instruction_path = excluded.instruction_path,
          mode = excluded.mode,
          updated_at = excluded.updated_at
      `)
      .run(id("skill"), ownerBuddy.id, required("skill name", name), path, mode, timestamp, timestamp);
    return this.db
      .prepare("SELECT * FROM buddy_skills WHERE buddy_id = ? AND name = ?")
      .get(ownerBuddy.id, name.trim());
  }

  removeBuddySkill(buddy, name) {
    const ownerBuddy = this.#requireBuddy(buddy);
    return (
      this.db
        .prepare("DELETE FROM buddy_skills WHERE buddy_id = ? AND name = ?")
        .run(ownerBuddy.id, required("skill name", name)).changes > 0
    );
  }

  listBuddySkills(buddy) {
    const ownerBuddy = this.#requireBuddy(buddy);
    return rows(
      this.db.prepare("SELECT * FROM buddy_skills WHERE buddy_id = ? ORDER BY name"),
      ownerBuddy.id,
    );
  }

  createDelegation({
    fromBuddy,
    toBuddy,
    workspace,
    project,
    purpose,
    parentConversationId,
    childConversationId,
    status = "pending",
  }) {
    assertOneOf("delegation status", status, DELEGATION_STATUSES);
    const from = this.#requireBuddy(fromBuddy);
    const to = this.#requireBuddy(toBuddy);
    if (from.id === to.id) throw new Error("a Buddy cannot delegate to itself");
    const ownerWorkspace = this.#requireProject(workspace);
    this.#requireBuddy(from, ownerWorkspace);
    this.#requireBuddy(to, ownerWorkspace);
    const ownerProject = project ? this.#requireBuddyProject(project) : null;
    if (ownerProject && ownerProject.workspace_id !== ownerWorkspace.id) {
      throw new Error("Buddy project does not belong to the delegation workspace");
    }
    if (ownerProject && ownerProject.buddy_id !== from.id) {
      throw new Error("Buddy project does not belong to the delegating Buddy");
    }
    const timestamp = now();
    const delegationId = id("delegation");
    this.db
      .prepare(`
        INSERT INTO buddy_delegations (
          id, from_buddy_id, to_buddy_id, workspace_id, buddy_project_id,
          purpose, parent_conversation_id, child_conversation_id, status,
          outcome, created_at, updated_at, completed_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?, ?)
      `)
      .run(
        delegationId, from.id, to.id, ownerWorkspace.id, ownerProject?.id || null,
        required("delegation purpose", purpose), parentConversationId || null,
        childConversationId || null, status, timestamp, timestamp,
        ["complete", "failed", "cancelled"].includes(status) ? timestamp : null,
      );
    return this.getDelegation(delegationId);
  }

  getDelegation(delegation) {
    const row = this.db.prepare("SELECT * FROM buddy_delegations WHERE id = ?").get(delegation);
    return row ? { ...row } : null;
  }

  claimDelegationDispatch(delegation, { claimToken, leaseSeconds = 120 } = {}) {
    const current = this.getDelegation(delegation);
    if (!current) throw new Error(`delegation not found: ${delegation}`);
    const token = required("delegation dispatch claim token", claimToken);
    const claimedAt = now();
    const expiresAt = new Date(
      Date.parse(claimedAt) + Math.max(1, Number(leaseSeconds) || 120) * 1000,
    ).toISOString();
    const result = this.db
      .prepare(`
        UPDATE buddy_delegations
        SET dispatch_token = ?, dispatch_expires_at = ?, updated_at = ?
        WHERE id = ?
          AND status = 'pending'
          AND child_conversation_id IS NULL
          AND (
            dispatch_token IS NULL
            OR dispatch_expires_at IS NULL
            OR dispatch_expires_at <= ?
          )
      `)
      .run(token, expiresAt, claimedAt, current.id, claimedAt);
    return {
      ...this.getDelegation(current.id),
      dispatch_claim_acquired: result.changes === 1,
    };
  }

  bindDelegationConversation(delegation, { claimToken, childConversationId }) {
    const current = this.getDelegation(delegation);
    if (!current) throw new Error(`delegation not found: ${delegation}`);
    const token = required("delegation dispatch claim token", claimToken);
    const conversation = required("delegation child conversation", childConversationId);
    if (current.child_conversation_id === conversation && current.status === "active") {
      return current;
    }
    const timestamp = now();
    const result = this.db
      .prepare(`
        UPDATE buddy_delegations
        SET status = 'active', child_conversation_id = ?,
          dispatch_token = NULL, dispatch_expires_at = NULL, updated_at = ?
        WHERE id = ?
          AND status = 'pending'
          AND child_conversation_id IS NULL
          AND dispatch_token = ?
      `)
      .run(conversation, timestamp, current.id, token);
    if (result.changes !== 1) {
      throw new Error("delegation dispatch claim is not owned by this executor");
    }
    return this.getDelegation(current.id);
  }

  failDelegationDispatch(delegation, { claimToken, error }) {
    const current = this.getDelegation(delegation);
    if (!current) throw new Error(`delegation not found: ${delegation}`);
    const token = required("delegation dispatch claim token", claimToken);
    const timestamp = now();
    const result = this.db
      .prepare(`
        UPDATE buddy_delegations
        SET status = 'failed', outcome = ?, dispatch_token = NULL,
          dispatch_expires_at = NULL, updated_at = ?, completed_at = ?
        WHERE id = ?
          AND status = 'pending'
          AND child_conversation_id IS NULL
          AND dispatch_token = ?
      `)
      .run(String(error || "Delegation dispatch failed"), timestamp, timestamp, current.id, token);
    if (result.changes !== 1) {
      throw new Error("delegation dispatch claim is not owned by this executor");
    }
    return this.getDelegation(current.id);
  }

  updateDelegation(delegation, {
    status,
    childConversationId,
    outcome,
  }) {
    const current = this.getDelegation(delegation);
    if (!current) throw new Error(`delegation not found: ${delegation}`);
    const nextStatus = status ?? current.status;
    assertOneOf("delegation status", nextStatus, DELEGATION_STATUSES);
    const timestamp = now();
    this.db
      .prepare(`
        UPDATE buddy_delegations SET status = ?, child_conversation_id = ?,
          outcome = ?, updated_at = ?, completed_at = ? WHERE id = ?
      `)
      .run(
        nextStatus,
        childConversationId === undefined ? current.child_conversation_id : childConversationId || null,
        outcome === undefined ? current.outcome : outcome || null,
        timestamp,
        ["complete", "failed", "cancelled"].includes(nextStatus)
          ? current.completed_at || timestamp
          : null,
        current.id,
      );
    return this.getDelegation(current.id);
  }

  listDelegations({ buddy, workspace, status } = {}) {
    const conditions = [];
    const params = [];
    if (buddy) {
      const ownerBuddy = this.#requireBuddy(buddy);
      conditions.push("(from_buddy_id = ? OR to_buddy_id = ?)");
      params.push(ownerBuddy.id, ownerBuddy.id);
    }
    if (workspace) {
      conditions.push("workspace_id = ?");
      params.push(this.#requireProject(workspace).id);
    }
    if (status) {
      assertOneOf("delegation status", status, DELEGATION_STATUSES);
      conditions.push("status = ?");
      params.push(status);
    }
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_delegations
        ${conditions.length ? `WHERE ${conditions.join(" AND ")}` : ""}
        ORDER BY created_at DESC
      `),
      ...params,
    );
  }

  createReview({
    reviewer,
    subject,
    workspace,
    project,
    conversationId,
    status = "draft",
    verdict,
    score,
    summary,
    evidence = [],
  }) {
    assertOneOf("review status", status, REVIEW_STATUSES);
    if (verdict) assertOneOf("review verdict", verdict, REVIEW_VERDICTS);
    if (status === "complete" && (!verdict || !summary?.trim())) {
      throw new Error("a completed review requires verdict and summary");
    }
    if (!Array.isArray(evidence)) throw new Error("review evidence must be an array");
    if (status === "complete" && evidence.length === 0) {
      throw new Error("a completed review requires evidence");
    }
    const reviewerBuddy = this.#requireBuddy(reviewer);
    const subjectBuddy = this.#requireBuddy(subject);
    if (reviewerBuddy.id === subjectBuddy.id) {
      throw new Error("a Buddy cannot review itself");
    }
    const ownerWorkspace = this.#requireProject(workspace);
    this.#requireBuddy(reviewerBuddy, ownerWorkspace);
    this.#requireBuddy(subjectBuddy, ownerWorkspace);
    const ownerProject = project ? this.#requireBuddyProject(project) : null;
    if (ownerProject && ownerProject.workspace_id !== ownerWorkspace.id) {
      throw new Error("Buddy project does not belong to the review workspace");
    }
    if (ownerProject && ownerProject.buddy_id !== subjectBuddy.id) {
      throw new Error("Buddy project does not belong to the reviewed Buddy");
    }
    const timestamp = now();
    const reviewId = id("review");
    this.db
      .prepare(`
        INSERT INTO buddy_reviews (
          id, reviewer_buddy_id, subject_buddy_id, workspace_id,
          buddy_project_id, conversation_id, status, verdict, score, summary,
          evidence, created_at, updated_at, completed_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        reviewId, reviewerBuddy.id, subjectBuddy.id, ownerWorkspace.id,
        ownerProject?.id || null, conversationId || null, status, verdict || null,
        score === undefined ? null : Number(score), summary?.trim() || null,
        JSON.stringify(evidence), timestamp, timestamp,
        status === "complete" ? timestamp : null,
      );
    return this.getReview(reviewId);
  }

  getReview(review) {
    const row = this.db.prepare("SELECT * FROM buddy_reviews WHERE id = ?").get(review);
    return row ? { ...row, evidence: JSON.parse(row.evidence) } : null;
  }

  updateReview(review, changes = {}) {
    const current = this.getReview(review);
    if (!current) throw new Error(`review not found: ${review}`);
    const status = changes.status ?? current.status;
    const verdict = changes.verdict === undefined ? current.verdict : changes.verdict;
    const summary = changes.summary === undefined ? current.summary : changes.summary?.trim() || null;
    assertOneOf("review status", status, REVIEW_STATUSES);
    if (verdict) assertOneOf("review verdict", verdict, REVIEW_VERDICTS);
    if (status === "complete" && (!verdict || !summary)) {
      throw new Error("a completed review requires verdict and summary");
    }
    const evidence = changes.evidence === undefined ? current.evidence : changes.evidence;
    if (!Array.isArray(evidence)) throw new Error("review evidence must be an array");
    if (status === "complete" && evidence.length === 0) {
      throw new Error("a completed review requires evidence");
    }
    const timestamp = now();
    this.db
      .prepare(`
        UPDATE buddy_reviews SET status = ?, verdict = ?, score = ?, summary = ?,
          evidence = ?, updated_at = ?, completed_at = ? WHERE id = ?
      `)
      .run(
        status, verdict || null,
        changes.score === undefined ? current.score : Number(changes.score),
        summary, JSON.stringify(evidence), timestamp,
        status === "complete" ? current.completed_at || timestamp : null,
        current.id,
      );
    return this.getReview(current.id);
  }

  listReviews({ buddy, workspace, status } = {}) {
    const conditions = [];
    const params = [];
    if (buddy) {
      const ownerBuddy = this.#requireBuddy(buddy);
      conditions.push("(reviewer_buddy_id = ? OR subject_buddy_id = ?)");
      params.push(ownerBuddy.id, ownerBuddy.id);
    }
    if (workspace) {
      conditions.push("workspace_id = ?");
      params.push(this.#requireProject(workspace).id);
    }
    if (status) {
      assertOneOf("review status", status, REVIEW_STATUSES);
      conditions.push("status = ?");
      params.push(status);
    }
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_reviews
        ${conditions.length ? `WHERE ${conditions.join(" AND ")}` : ""}
        ORDER BY created_at DESC
      `),
      ...params,
    ).map((row) => ({ ...row, evidence: JSON.parse(row.evidence) }));
  }

  createSprint({ project, name, goal, status = "planned" }) {
    assertOneOf("sprint status", status, SPRINT_STATUSES);
    const ownerProject = this.#requireProject(project);
    const timestamp = now();
    const sprint = {
      id: id("sprint"),
      projectId: ownerProject.id,
      name: required("sprint name", name),
      goal: goal?.trim() || null,
      status,
      startsAt: status === "active" ? timestamp : null,
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    this.db
      .prepare(`
        INSERT INTO sprints (
          id, project_id, name, goal, status, starts_at, ends_at, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, NULL, ?, ?)
      `)
      .run(
        sprint.id,
        sprint.projectId,
        sprint.name,
        sprint.goal,
        sprint.status,
        sprint.startsAt,
        sprint.createdAt,
        sprint.updatedAt,
      );
    return this.getSprint(sprint.id);
  }

  getSprint(id) {
    const row = this.db.prepare("SELECT * FROM sprints WHERE id = ?").get(id);
    return row ? { ...row } : null;
  }

  getActiveSprint(project) {
    const ownerProject = this.#requireProject(project);
    const row = this.db
      .prepare("SELECT * FROM sprints WHERE project_id = ? AND status = 'active'")
      .get(ownerProject.id);
    return row ? { ...row } : null;
  }

  completeSprint(sprintId) {
    const sprint = this.#requireSprint(sprintId);
    const timestamp = now();
    this.db
      .prepare(`
        UPDATE sprints
        SET status = 'completed', ends_at = ?, updated_at = ?
        WHERE id = ?
      `)
      .run(timestamp, timestamp, sprint.id);
    return this.getSprint(sprint.id);
  }

  newProject({
    buddy,
    workspace,
    title,
    objective,
    definitionOfDone,
    sprint,
    status = "backlog",
    priority = 0,
    nextAction,
    blockedReason,
    sourcePath,
    externalKey,
    todos = [],
  }) {
    assertOneOf("Buddy project status", status, BUDDY_PROJECT_STATUSES);
    if (status === "blocked" && !blockedReason?.trim()) {
      throw new Error("blocked reason is required when blocking a Buddy project");
    }
    const ownerWorkspace = this.#requireProject(workspace);
    const ownerBuddy = this.#requireBuddy(buddy, ownerWorkspace);
    const ownerSprint = sprint ? this.#requireSprint(sprint, ownerWorkspace) : null;
    if (!Array.isArray(todos)) throw new Error("todos must be an array");
    const timestamp = now();
    const projectId = id("buddy_project");
    try {
      this.db.exec("BEGIN");
      this.db
        .prepare(`
          INSERT INTO owned_projects (
            id, workspace_id, buddy_id, sprint_id, title, objective,
            definition_of_done, status, priority, next_action, blocked_reason,
            source_path, external_key, created_at, updated_at, completed_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `)
        .run(
          projectId,
          ownerWorkspace.id,
          ownerBuddy.id,
          ownerSprint?.id || null,
          required("Buddy project title", title),
          objective?.trim() || null,
          required("definition of done", definitionOfDone),
          status,
          Number(priority) || 0,
          nextAction?.trim() || null,
          status === "blocked" ? blockedReason.trim() : null,
          sourcePath ? this.#projectPath(ownerWorkspace, sourcePath) : null,
          externalKey?.trim() || null,
          timestamp,
          timestamp,
          ["done", "cancelled"].includes(status) ? timestamp : null,
        );
      for (let position = 0; position < todos.length; position += 1) {
        const todo = todos[position];
        this.#insertTodo(projectId, {
          ...todo,
          position,
        }, timestamp);
      }
      this.db.exec("COMMIT");
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
    return this.getBuddyProject(projectId);
  }

  upsertBuddyProject(input) {
    const externalKey = required("external key", input.externalKey);
    const ownerWorkspace = this.#requireProject(input.workspace);
    const ownerBuddy = this.#requireBuddy(input.buddy, ownerWorkspace);
    const existing = this.db
      .prepare(
        "SELECT * FROM owned_projects WHERE workspace_id = ? AND external_key = ?",
      )
      .get(ownerWorkspace.id, externalKey);

    if (!existing) {
      return this.newProject({
        ...input,
        buddy: ownerBuddy.id,
        workspace: ownerWorkspace.id,
        externalKey,
      });
    }
    if (existing.buddy_id !== ownerBuddy.id) {
      throw new Error("external key belongs to another Buddy");
    }

    const existingTodos = this.listTodos(existing.id, { includeClosed: true });
    const existingTodoTitles = new Set(existingTodos.map((todo) => todo.title));
    const todoOperations = (input.todos || [])
      .filter((todo) => !existingTodoTitles.has(required("todo title", todo.title)))
      .map((todo) => ({ operation: "add", ...todo }));

    return this.updateProject(existing.id, {
      title: input.title,
      objective: input.objective,
      definitionOfDone: input.definitionOfDone,
      sprint: input.sprint,
      status: input.status,
      priority: input.priority,
      nextAction: input.nextAction,
      blockedReason: input.blockedReason,
      sourcePath: input.sourcePath,
      todoOperations,
    });
  }

  getBuddyProject(project) {
    const row =
      typeof project === "object" && project?.id
        ? project
        : this.db.prepare("SELECT * FROM owned_projects WHERE id = ?").get(project);
    if (!row) return null;
    return {
      ...row,
      todos: this.listTodos(row.id, { includeClosed: true }),
    };
  }

  listBuddyOwnedProjects({ buddy, workspace, sprint, includeClosed = false } = {}) {
    const conditions = [];
    const params = [];
    if (buddy) {
      conditions.push("owned_projects.buddy_id = ?");
      params.push(this.#requireBuddy(buddy).id);
    }
    if (workspace) {
      conditions.push("owned_projects.workspace_id = ?");
      params.push(this.#requireProject(workspace).id);
    }
    if (sprint) {
      conditions.push("owned_projects.sprint_id = ?");
      params.push(this.#requireSprint(sprint).id);
    }
    if (!includeClosed) {
      conditions.push("owned_projects.status NOT IN ('done', 'cancelled')");
    }
    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    return rows(
      this.db.prepare(`
        SELECT owned_projects.*, projects.name AS workspace_name,
          projects.slug AS workspace_slug, buddies.name AS buddy_name,
          sprints.name AS sprint_name
        FROM owned_projects
        JOIN projects ON projects.id = owned_projects.workspace_id
        JOIN buddies ON buddies.id = owned_projects.buddy_id
        LEFT JOIN sprints ON sprints.id = owned_projects.sprint_id
        ${where}
        ORDER BY owned_projects.priority DESC, owned_projects.created_at
      `),
      ...params,
    ).map((project) => ({
      ...project,
      todos: this.listTodos(project.id, { includeClosed: true }),
    }));
  }

  listTodos(project, { includeClosed = false } = {}) {
    const ownerProject = this.#requireBuddyProject(project);
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_todos
        WHERE buddy_project_id = ?
          ${includeClosed ? "" : "AND status NOT IN ('done', 'cancelled')"}
        ORDER BY position, created_at
      `),
      ownerProject.id,
    );
  }

  updateProject(project, changes = {}) {
    const ownerProject = this.#requireBuddyProject(project);
    const timestamp = now();
    const nextStatus = changes.status ?? ownerProject.status;
    assertOneOf("Buddy project status", nextStatus, BUDDY_PROJECT_STATUSES);
    const nextBlockedReason =
      nextStatus === "blocked"
        ? changes.blockedReason?.trim() || ownerProject.blocked_reason
        : null;
    if (nextStatus === "blocked" && !nextBlockedReason) {
      throw new Error("blocked reason is required when blocking a Buddy project");
    }
    const workspace = this.#requireProject(ownerProject.workspace_id);
    const sprint =
      changes.sprint === null
        ? null
        : changes.sprint
          ? this.#requireSprint(changes.sprint, workspace)
          : undefined;
    if (changes.todoOperations && !Array.isArray(changes.todoOperations)) {
      throw new Error("todoOperations must be an array");
    }
    try {
      this.db.exec("BEGIN");
      this.db
        .prepare(`
          UPDATE owned_projects SET
            title = ?, objective = ?, definition_of_done = ?, status = ?,
            priority = ?, next_action = ?, blocked_reason = ?, sprint_id = ?,
            source_path = ?, updated_at = ?, completed_at = ?
          WHERE id = ?
        `)
        .run(
          changes.title === undefined
            ? ownerProject.title
            : required("Buddy project title", changes.title),
          changes.objective === undefined
            ? ownerProject.objective
            : changes.objective?.trim() || null,
          changes.definitionOfDone === undefined
            ? ownerProject.definition_of_done
            : required("definition of done", changes.definitionOfDone),
          nextStatus,
          changes.priority === undefined
            ? ownerProject.priority
            : Number(changes.priority) || 0,
          changes.nextAction === undefined
            ? ownerProject.next_action
            : changes.nextAction?.trim() || null,
          nextBlockedReason,
          sprint === undefined ? ownerProject.sprint_id : sprint?.id || null,
          changes.sourcePath === undefined
            ? ownerProject.source_path
            : changes.sourcePath
              ? this.#projectPath(workspace, changes.sourcePath)
              : null,
          timestamp,
          ["done", "cancelled"].includes(nextStatus)
            ? ownerProject.completed_at || timestamp
            : null,
          ownerProject.id,
        );
      for (const operation of changes.todoOperations || []) {
        if (operation.operation === "add") {
          const nextPosition =
            this.db
              .prepare(
                "SELECT COALESCE(MAX(position), -1) + 1 AS position FROM buddy_todos WHERE buddy_project_id = ?",
              )
              .get(ownerProject.id).position;
          this.#insertTodo(ownerProject.id, { ...operation, position: nextPosition }, timestamp);
        } else if (operation.operation === "update") {
          this.#updateTodo(ownerProject.id, operation, timestamp);
        } else {
          throw new Error(`unknown todo operation: ${operation.operation}`);
        }
      }
      this.db.exec("COMMIT");
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
    return this.getBuddyProject(ownerProject.id);
  }

  readBuddyMemory(buddy, { recentJournalLimit = 7 } = {}) {
    const ownerBuddy = this.#requireBuddy(buddy);
    if (!ownerBuddy.memory_path) {
      return { summary: "", recentJournal: [] };
    }
    const root = this.#memoryRoot(ownerBuddy);
    const summaryPath = this.#containedPath(root, "MEMORY.md");
    let summary = "";
    try {
      summary = readFileSync(summaryPath, "utf8");
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
    const journal = [];
    const today = new Date();
    for (let offset = 0; offset < Math.max(0, Number(recentJournalLimit) || 0); offset += 1) {
      const date = new Date(today);
      date.setUTCDate(today.getUTCDate() - offset);
      const day = date.toISOString().slice(0, 10);
      const path = this.#containedPath(root, "journal", `${day}.md`);
      try {
        journal.push({ path, content: readFileSync(path, "utf8") });
      } catch (error) {
        if (error.code !== "ENOENT") throw error;
      }
    }
    return { summary, recentJournal: journal };
  }

  remember(buddy, { content, kind = "journal", date = new Date() }) {
    assertOneOf("memory kind", kind, ["journal", "curated"]);
    const ownerBuddy = this.#requireBuddy(buddy);
    const root = this.#memoryRoot(ownerBuddy);
    const timestamp = date instanceof Date ? date.toISOString() : new Date(date).toISOString();
    const body = required("memory content", content);
    const path =
      kind === "journal"
        ? this.#containedPath(root, "journal", `${timestamp.slice(0, 10)}.md`)
        : this.#containedPath(root, "MEMORY.md");
    mkdirSync(dirname(path), { recursive: true });
    this.#containedPath(root, relative(root, path));
    const entry =
      kind === "journal"
        ? `\n## ${timestamp}\n\n${body}\n`
        : `\n## ${timestamp.slice(0, 10)}\n\n${body}\n`;
    appendFileSync(path, entry, "utf8");
    return { buddy_id: ownerBuddy.id, kind, path, content: body, written_at: timestamp };
  }

  compactMemory(
    buddy,
    {
      summary,
      retainDays = 7,
      maxActiveCharacters = 50_000,
      dryRun = false,
      date = new Date(),
    } = {},
  ) {
    const ownerBuddy = this.#requireBuddy(buddy);
    const root = this.#memoryRoot(ownerBuddy);
    const journalRoot = this.#containedPath(root, "journal");
    const summaryPath = this.#containedPath(root, "MEMORY.md");
    const indexPath = this.#containedPath(root, "index.json");
    const files = existsSync(journalRoot)
      ? readdirSync(journalRoot)
          .filter((name) => /^\d{4}-\d{2}-\d{2}\.md$/.test(name))
          .sort()
          .map((name) => {
            const path = this.#containedPath(journalRoot, name);
            const content = readFileSync(path, "utf8");
            return { name, path, content, characters: content.length };
          })
      : [];
    const keepCount = Math.max(0, Number(retainDays) || 0);
    const candidates = files.slice(0, Math.max(0, files.length - keepCount));
    let activeCharacters = files.reduce((total, file) => total + file.characters, 0);
    for (const file of files) {
      if (activeCharacters <= Math.max(0, Number(maxActiveCharacters) || 0)) break;
      if (!candidates.includes(file)) candidates.push(file);
      activeCharacters -= file.characters;
    }
    candidates.sort((left, right) => left.name.localeCompare(right.name));
    const sources = candidates.map((file) => ({
      path: `journal/${file.name}`,
      sha256: createHash("sha256").update(file.content).digest("hex"),
      characters: file.characters,
    }));
    const plan = {
      buddyId: ownerBuddy.id,
      dryRun: Boolean(dryRun),
      compact: candidates.length > 0,
      retainedJournalFiles: files.length - candidates.length,
      archivedJournalFiles: sources,
    };
    if (dryRun || candidates.length === 0) return plan;
    const rollup = required("memory compaction summary", summary);
    const timestamp = date instanceof Date ? date.toISOString() : new Date(date).toISOString();
    const existingSummary = existsSync(summaryPath) ? readFileSync(summaryPath, "utf8") : "";
    const sourceList = sources.map((source) => `- ${source.path} (${source.sha256})`).join("\n");
    const nextSummary = `${existingSummary.trimEnd()}\n\n## Compaction ${timestamp}\n\n${rollup}\n\nSources:\n${sourceList}\n`;
    let index = { version: 1, compactions: [] };
    if (existsSync(indexPath)) {
      const parsed = JSON.parse(readFileSync(indexPath, "utf8"));
      if (parsed?.version !== 1 || !Array.isArray(parsed.compactions)) {
        throw new Error("unsupported Buddy memory index");
      }
      index = parsed;
    }
    const signature = createHash("sha256")
      .update(sources.map((source) => source.sha256).join(":"))
      .digest("hex");
    if (index.compactions.some((entry) => entry.signature === signature)) {
      return { ...plan, compact: false, alreadyCompacted: true };
    }
    const nextIndex = {
      version: 1,
      compactions: [
        ...index.compactions,
        {
          id: id("compaction"),
          signature,
          createdAt: timestamp,
          summary: rollup,
          sources,
        },
      ],
    };
    mkdirSync(root, { recursive: true });
    const tempSummary = this.#containedPath(root, `.MEMORY.${randomUUID()}.tmp`);
    const tempIndex = this.#containedPath(root, `.index.${randomUUID()}.tmp`);
    const backupSummary = this.#containedPath(root, `.MEMORY.${randomUUID()}.bak`);
    const backupIndex = this.#containedPath(root, `.index.${randomUUID()}.bak`);
    const moved = [];
    let summaryBackedUp = false;
    let indexBackedUp = false;
    try {
      writeFileSync(tempSummary, nextSummary, "utf8");
      writeFileSync(tempIndex, `${JSON.stringify(nextIndex, null, 2)}\n`, "utf8");
      for (const file of candidates) {
        const archiveDirectory = this.#containedPath(
          root,
          "archive",
          file.name.slice(0, 7),
        );
        mkdirSync(archiveDirectory, { recursive: true });
        const archivePath = this.#containedPath(archiveDirectory, file.name);
        if (existsSync(archivePath)) {
          const archivedHash = createHash("sha256")
            .update(readFileSync(archivePath))
            .digest("hex");
          const source = sources.find((item) => item.path.endsWith(file.name));
          if (archivedHash !== source.sha256) {
            throw new Error(`memory archive collision: ${file.name}`);
          }
          rmSync(file.path);
        } else {
          renameSync(file.path, archivePath);
          moved.push({ from: file.path, to: archivePath });
        }
      }
      if (existsSync(summaryPath)) {
        renameSync(summaryPath, backupSummary);
        summaryBackedUp = true;
      }
      if (existsSync(indexPath)) {
        renameSync(indexPath, backupIndex);
        indexBackedUp = true;
      }
      renameSync(tempSummary, summaryPath);
      renameSync(tempIndex, indexPath);
      rmSync(backupSummary, { force: true });
      rmSync(backupIndex, { force: true });
    } catch (error) {
      rmSync(tempSummary, { force: true });
      rmSync(tempIndex, { force: true });
      if (summaryBackedUp) {
        rmSync(summaryPath, { force: true });
        renameSync(backupSummary, summaryPath);
      }
      if (indexBackedUp) {
        rmSync(indexPath, { force: true });
        renameSync(backupIndex, indexPath);
      }
      for (const file of moved.reverse()) {
        if (existsSync(file.to) && !existsSync(file.from)) renameSync(file.to, file.from);
      }
      throw error;
    }
    return {
      ...plan,
      compactedAt: timestamp,
      indexPath,
      summaryPath,
      signature,
    };
  }

  createWorkItem({
    project,
    title,
    definitionOfDone,
    objective,
    buddy,
    sprint,
    status = "backlog",
    priority = 0,
    nextAction,
    kind = "task",
    externalKey,
    sourcePath,
    blockedReason,
  }) {
    assertOneOf("work item status", status, WORK_ITEM_STATUSES);
    if (status === "blocked" && !blockedReason?.trim()) {
      throw new Error("blocked reason is required when creating blocked work");
    }
    const ownerProject = this.#requireProject(project);
    const ownerBuddy = buddy ? this.#requireBuddy(buddy, ownerProject) : null;
    const ownerSprint = sprint ? this.#requireSprint(sprint, ownerProject) : null;
    const timestamp = now();
    const workItem = {
      id: id("work"),
      projectId: ownerProject.id,
      sprintId: ownerSprint?.id || null,
      buddyId: ownerBuddy?.id || null,
      title: required("work item title", title),
      kind: required("work item kind", kind),
      externalKey: externalKey?.trim() || null,
      sourcePath: sourcePath ? this.#projectPath(ownerProject, sourcePath) : null,
      objective: objective?.trim() || null,
      definitionOfDone: required("definition of done", definitionOfDone),
      status,
      priority: Number(priority) || 0,
      nextAction: nextAction?.trim() || null,
      blockedReason: status === "blocked" ? blockedReason.trim() : null,
      createdAt: timestamp,
      updatedAt: timestamp,
      completedAt: status === "done" ? timestamp : null,
    };
    this.db
      .prepare(`
        INSERT INTO work_items (
          id, project_id, sprint_id, buddy_id, title, kind, external_key, source_path, objective,
          definition_of_done, status, priority, next_action, blocked_reason,
          created_at, updated_at, completed_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        workItem.id,
        workItem.projectId,
        workItem.sprintId,
        workItem.buddyId,
        workItem.title,
        workItem.kind,
        workItem.externalKey,
        workItem.sourcePath,
        workItem.objective,
        workItem.definitionOfDone,
        workItem.status,
        workItem.priority,
        workItem.nextAction,
        workItem.blockedReason,
        workItem.createdAt,
        workItem.updatedAt,
        workItem.completedAt,
      );
    return this.getWorkItem(workItem.id);
  }

  upsertWorkItem(input) {
    if (!input.externalKey?.trim()) {
      return this.createWorkItem(input);
    }
    const ownerProject = this.#requireProject(input.project);
    const existing = this.db
      .prepare("SELECT * FROM work_items WHERE project_id = ? AND external_key = ?")
      .get(ownerProject.id, input.externalKey.trim());
    if (!existing) return this.createWorkItem(input);

    const ownerBuddy = input.buddy ? this.#requireBuddy(input.buddy, ownerProject) : null;
    const ownerSprint = input.sprint ? this.#requireSprint(input.sprint, ownerProject) : null;
    assertOneOf("work item status", input.status, WORK_ITEM_STATUSES);
    if (input.status === "blocked" && !input.blockedReason?.trim()) {
      throw new Error("blocked reason is required when blocking a work item");
    }
    const timestamp = now();
    this.db
      .prepare(`
        UPDATE work_items SET
          sprint_id = ?, buddy_id = ?, title = ?, kind = ?, source_path = ?,
          objective = ?, definition_of_done = ?, status = ?, priority = ?,
          next_action = ?, blocked_reason = ?, updated_at = ?, completed_at = ?
        WHERE id = ?
      `)
      .run(
        ownerSprint?.id || null,
        ownerBuddy?.id || null,
        required("work item title", input.title),
        required("work item kind", input.kind || "task"),
        input.sourcePath ? this.#projectPath(ownerProject, input.sourcePath) : null,
        input.objective?.trim() || null,
        required("definition of done", input.definitionOfDone),
        input.status,
        Number(input.priority) || 0,
        input.nextAction?.trim() || null,
        input.status === "blocked" ? input.blockedReason.trim() : null,
        timestamp,
        input.status === "done" ? timestamp : null,
        existing.id,
      );
    return this.getWorkItem(existing.id);
  }

  getWorkItem(id) {
    const row = this.db.prepare("SELECT * FROM work_items WHERE id = ?").get(id);
    return row ? { ...row } : null;
  }

  updateWorkItemStatus(id, status, { blockedReason, nextAction } = {}) {
    assertOneOf("work item status", status, WORK_ITEM_STATUSES);
    this.#requireWorkItem(id);
    if (status === "blocked" && !blockedReason?.trim()) {
      throw new Error("blocked reason is required when blocking a work item");
    }
    const timestamp = now();
    this.db
      .prepare(`
        UPDATE work_items
        SET status = ?,
            blocked_reason = ?,
            next_action = COALESCE(?, next_action),
            completed_at = ?,
            updated_at = ?
        WHERE id = ?
      `)
      .run(
        status,
        status === "blocked" ? blockedReason.trim() : null,
        nextAction?.trim() || null,
        status === "done" ? timestamp : null,
        timestamp,
        id,
      );
    return this.getWorkItem(id);
  }

  listWorkItems({ project, buddy, sprint, includeClosed = false } = {}) {
    const conditions = [];
    const params = [];
    if (project) {
      conditions.push("work_items.project_id = ?");
      params.push(this.#requireProject(project).id);
    }
    if (buddy) {
      conditions.push("work_items.buddy_id = ?");
      params.push(this.#requireBuddy(buddy).id);
    }
    if (sprint) {
      conditions.push("work_items.sprint_id = ?");
      params.push(this.#requireSprint(sprint).id);
    }
    if (!includeClosed) {
      conditions.push("work_items.status NOT IN ('done', 'cancelled')");
    }
    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    return rows(
      this.db.prepare(`
        SELECT work_items.*, buddies.name AS buddy_name, sprints.name AS sprint_name
        FROM work_items
        LEFT JOIN buddies ON buddies.id = work_items.buddy_id
        LEFT JOIN sprints ON sprints.id = work_items.sprint_id
        ${where}
        ORDER BY work_items.priority DESC, work_items.created_at
      `),
      ...params,
    );
  }

  currentWork(project) {
    const ownerProject = this.#requireProject(project);
    const activeSprint = this.getActiveSprint(ownerProject.id);
    const workItems = activeSprint
      ? this.listWorkItems({ project: ownerProject.id, sprint: activeSprint.id })
      : this.listWorkItems({ project: ownerProject.id });
    return {
      project: ownerProject,
      sprint: activeSprint,
      workItems,
    };
  }

  auditWorkMigration() {
    const summary = this.db
      .prepare(`
        SELECT
          COUNT(*) AS open_legacy,
          SUM(CASE WHEN owned_projects.id IS NOT NULL THEN 1 ELSE 0 END) AS migrated,
          SUM(CASE WHEN owned_projects.id IS NULL THEN 1 ELSE 0 END) AS unmigrated
        FROM work_items
        LEFT JOIN owned_projects
          ON owned_projects.workspace_id = work_items.project_id
          AND owned_projects.external_key = work_items.external_key
        WHERE work_items.status NOT IN ('done', 'cancelled')
      `)
      .get();
    const unmigratedItems = rows(
      this.db.prepare(`
        SELECT work_items.id, work_items.project_id, work_items.buddy_id,
          work_items.external_key, work_items.title, work_items.status
        FROM work_items
        LEFT JOIN owned_projects
          ON owned_projects.workspace_id = work_items.project_id
          AND owned_projects.external_key = work_items.external_key
        WHERE work_items.status NOT IN ('done', 'cancelled')
          AND owned_projects.id IS NULL
        ORDER BY work_items.priority DESC, work_items.created_at
      `),
    );
    return {
      openLegacy: Number(summary.open_legacy) || 0,
      migrated: Number(summary.migrated) || 0,
      unmigrated: Number(summary.unmigrated) || 0,
      unmigratedItems,
    };
  }

  dashboard() {
    const projects = this.listProjects();
    const buddies = this.listBuddies().map((buddy) => ({
      ...buddy,
      projects: this.listBuddyProjects(buddy.id),
      conversations: this.listConversationLinks(buddy.id),
    }));
    const sprints = rows(
      this.db.prepare(`
        SELECT sprints.*, projects.slug AS project_slug
        FROM sprints
        JOIN projects ON projects.id = sprints.project_id
        ORDER BY
          CASE sprints.status WHEN 'active' THEN 0 WHEN 'planned' THEN 1 ELSE 2 END,
          sprints.created_at DESC
      `),
    );
    return {
      projects,
      buddies,
      sprints,
      workItems: this.listWorkItems({ includeClosed: true }),
      buddyOwnedProjects: this.listBuddyOwnedProjects({ includeClosed: true }),
    };
  }

  overview({ recentSince } = {}) {
    const buddies = this.listBuddies();
    const workspaces = this.listProjects();
    const workspaceById = new Map(workspaces.map((workspace) => [workspace.id, workspace]));
    const relationships = rows(
      this.db.prepare(`
        SELECT * FROM buddy_relationships
        WHERE kind IN ('manager', 'reports_to')
        ORDER BY created_at
      `),
    );
    const managementPairs = new Map();
    for (const relationship of relationships) {
      const managerId =
        relationship.kind === "manager"
          ? relationship.from_buddy_id
          : relationship.to_buddy_id;
      const reportId =
        relationship.kind === "manager"
          ? relationship.to_buddy_id
          : relationship.from_buddy_id;
      managementPairs.set(`${managerId}:${reportId}`, { managerId, reportId });
    }
    const managerByReport = new Map();
    const reportsByManager = new Map();
    for (const { managerId, reportId } of managementPairs.values()) {
      if (!managerByReport.has(reportId)) managerByReport.set(reportId, managerId);
      const reports = reportsByManager.get(managerId) || new Set();
      reports.add(reportId);
      reportsByManager.set(managerId, reports);
    }

    const buddyById = new Map(buddies.map((buddy) => [buddy.id, buddy]));
    const openProjects = this.listBuddyOwnedProjects();
    const workByBuddy = new Map();
    for (const project of openProjects) {
      const work = workByBuddy.get(project.buddy_id) || [];
      work.push(project);
      workByBuddy.set(project.buddy_id, work);
    }
    const employee = (buddy) => {
      const work = workByBuddy.get(buddy.id) || [];
      const reportIds = reportsByManager.get(buddy.id) || new Set();
      return {
        buddy,
        managerId: managerByReport.get(buddy.id) || null,
        workspaces: this.listBuddyWorkspaces(buddy.id),
        team: [...reportIds]
          .map((reportId) => buddyById.get(reportId))
          .filter(Boolean)
          .map(({ id: reportId, name, role, status }) => ({
            id: reportId,
            name,
            role,
            status,
          })),
        currentWork: {
          open: work.length,
          active: work.filter((project) => project.status === "in_progress").length,
          blocked: work.filter((project) => project.status === "blocked").length,
          review: work.filter((project) => project.status === "review").length,
          nextActionMissing: work.filter((project) => !project.next_action).length,
        },
      };
    };
    const employees = buddies.map(employee);
    const cutoff =
      recentSince === undefined
        ? Date.now() - 7 * 24 * 60 * 60 * 1000
        : new Date(recentSince).getTime();
    if (!Number.isFinite(cutoff)) throw new Error("recentSince must be a valid date");
    const recentRuns = [];
    for (const buddy of buddies) {
      for (const conversation of this.listConversationLinks(buddy.id)) {
        if (new Date(conversation.last_active_at).getTime() < cutoff) continue;
        const workspace = workspaceById.get(conversation.workspace_id);
        recentRuns.push({
          conversationId:
            conversation.unleashd_conversation_id ||
            conversation.provider_session_id ||
            conversation.id,
          buddyId: buddy.id,
          buddyName: buddy.name,
          workspaceId: conversation.workspace_id,
          workspaceName: workspace?.name || "General",
          status: conversation.status,
          lastActiveAt: conversation.last_active_at,
        });
      }
    }
    recentRuns.sort(
      (left, right) =>
        new Date(right.lastActiveAt).getTime() - new Date(left.lastActiveAt).getTime(),
    );
    return {
      generatedAt: now(),
      employees,
      topLevel: employees.filter((item) => !item.managerId),
      recentRuns,
    };
  }

  getBuddyContext(buddy, { workspace, project } = {}) {
    const ownerBuddy = this.#requireBuddy(buddy);
    const homeWorkspace = this.#requireProject(ownerBuddy.project_id);
    const workspaces = this.listBuddyWorkspaces(ownerBuddy.id);
    const selectedWorkspace = workspace
      ? this.#requireProject(workspace)
      : workspaces.find((item) => item.id === ownerBuddy.project_id) || workspaces[0];
    if (selectedWorkspace && !this.#buddyHasProject(ownerBuddy.id, selectedWorkspace.id)) {
      throw new Error("buddy does not belong to the workspace");
    }
    const selectedProject = project ? this.#requireBuddyProject(project) : null;
    if (selectedProject && selectedProject.buddy_id !== ownerBuddy.id) {
      throw new Error("Buddy project does not belong to the buddy");
    }
    if (selectedProject && selectedWorkspace?.id !== selectedProject.workspace_id) {
      throw new Error("Buddy project does not belong to the workspace");
    }
    let soul = "";
    if (ownerBuddy.soul_path) {
      try {
        soul = readFileSync(
          this.#projectPath(homeWorkspace, ownerBuddy.soul_path),
          "utf8",
        );
      } catch (error) {
        if (error.code !== "ENOENT") throw error;
      }
    }
    const skills = this.listBuddySkills(ownerBuddy.id).map((skill) => ({
      ...skill,
      instruction_path: this.#projectPath(homeWorkspace, skill.instruction_path),
    }));
    return {
      buddy: ownerBuddy,
      relationships: this.listBuddyRelationships(ownerBuddy.id),
      skills,
      workspaces,
      workspace: selectedWorkspace || null,
      sprint: selectedWorkspace ? this.getActiveSprint(selectedWorkspace.id) : null,
      project: selectedProject ? this.getBuddyProject(selectedProject.id) : null,
      projects: selectedWorkspace
        ? this.listBuddyOwnedProjects({
            buddy: ownerBuddy.id,
            workspace: selectedWorkspace.id,
          })
        : [],
      legacyWorkItems: selectedWorkspace
        ? this.listWorkItems({ buddy: ownerBuddy.id, project: selectedWorkspace.id })
        : [],
      soul,
      memory: this.readBuddyMemory(ownerBuddy),
    };
  }

  createAutomation({
    buddy,
    workspace,
    project,
    name,
    scheduleKind,
    scheduleExpression,
    timezone = "UTC",
    jobKind,
    jobPayload,
    policy,
    enabled = true,
    nextRunAt,
  }) {
    const ownerBuddy = this.#requireBuddy(buddy);
    const ownerWorkspace = this.#requireProject(workspace || ownerBuddy.project_id);
    if (!this.#buddyHasProject(ownerBuddy.id, ownerWorkspace.id)) {
      throw new Error("buddy does not belong to the workspace");
    }
    const ownerProject = project ? this.#requireBuddyProject(project) : null;
    if (ownerProject && ownerProject.buddy_id !== ownerBuddy.id) {
      throw new Error("Buddy project does not belong to the buddy");
    }
    if (ownerProject && ownerWorkspace && ownerProject.workspace_id !== ownerWorkspace.id) {
      throw new Error("Buddy project does not belong to the workspace");
    }
    const definition = this.#validateAutomationDefinition({
      scheduleKind,
      scheduleExpression,
      timezone,
      jobKind,
      jobPayload,
    });
    const automationPolicy = this.#validateAutomationPolicy(
      policy,
      definition.jobKind,
      definition.jobPayload,
    );
    const timestamp = now();
    const automationId = id("automation");
    try {
      this.db.exec("BEGIN");
      this.db
        .prepare(`
          INSERT INTO buddy_automations (
            id, buddy_id, workspace_id, buddy_project_id, name, schedule_kind,
            schedule_expression, timezone, job_kind, job_payload, enabled,
            next_run_at, last_run_at, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?)
        `)
        .run(
          automationId,
          ownerBuddy.id,
          ownerWorkspace.id,
          ownerProject?.id || null,
          required("automation name", name),
          definition.scheduleKind,
          definition.scheduleExpression,
          definition.timezone,
          definition.jobKind,
          JSON.stringify(definition.jobPayload),
          enabled ? 1 : 0,
          nextRunAt ? new Date(nextRunAt).toISOString() : null,
          timestamp,
          timestamp,
        );
      this.#insertAutomationPolicy(automationId, automationPolicy, timestamp);
      this.db.exec("COMMIT");
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
    return this.getAutomation(automationId);
  }

  getAutomation(automation) {
    const row =
      typeof automation === "object" && automation?.id
        ? automation
        : this.db.prepare("SELECT * FROM buddy_automations WHERE id = ?").get(automation);
    return row ? this.#automationRow(row) : null;
  }

  listAutomations({ buddy, enabled } = {}) {
    const conditions = [];
    const params = [];
    if (buddy) {
      conditions.push("buddy_id = ?");
      params.push(this.#requireBuddy(buddy).id);
    }
    if (enabled !== undefined) {
      conditions.push("enabled = ?");
      params.push(enabled ? 1 : 0);
    }
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_automations
        ${conditions.length ? `WHERE ${conditions.join(" AND ")}` : ""}
        ORDER BY created_at
      `),
      ...params,
    ).map((row) => this.#automationRow(row));
  }

  updateAutomation(automation, changes = {}) {
    const current = this.#requireAutomation(automation);
    const definition = this.#validateAutomationDefinition({
      scheduleKind: changes.scheduleKind ?? current.schedule_kind,
      scheduleExpression: changes.scheduleExpression ?? current.schedule_expression,
      timezone: changes.timezone ?? current.timezone,
      jobKind: changes.jobKind ?? current.job_kind,
      jobPayload: changes.jobPayload ?? current.job_payload,
    });
    const automationPolicy = this.#validateAutomationPolicy(
      changes.policy,
      definition.jobKind,
      definition.jobPayload,
      current.policy,
    );
    const nextRunAt =
      changes.nextRunAt === undefined
        ? current.next_run_at
        : changes.nextRunAt
          ? new Date(changes.nextRunAt).toISOString()
          : null;
    const timestamp = now();
    try {
      this.db.exec("BEGIN");
      this.db
        .prepare(`
          UPDATE buddy_automations SET
            name = ?, schedule_kind = ?, schedule_expression = ?, timezone = ?,
            job_kind = ?, job_payload = ?, enabled = ?, next_run_at = ?, updated_at = ?
          WHERE id = ?
        `)
        .run(
          changes.name === undefined ? current.name : required("automation name", changes.name),
          definition.scheduleKind,
          definition.scheduleExpression,
          definition.timezone,
          definition.jobKind,
          JSON.stringify(definition.jobPayload),
          changes.enabled === undefined ? (current.enabled ? 1 : 0) : changes.enabled ? 1 : 0,
          nextRunAt,
          timestamp,
          current.id,
        );
      this.db
        .prepare(`
          UPDATE buddy_automation_policies SET
            max_runtime_seconds = ?, max_iterations = ?, max_tokens = ?,
            max_cost_usd = ?, allowed_operations = ?, updated_at = ?
          WHERE automation_id = ?
        `)
        .run(
          automationPolicy.max_runtime_seconds,
          automationPolicy.max_iterations,
          automationPolicy.max_tokens,
          automationPolicy.max_cost_usd,
          JSON.stringify(automationPolicy.allowed_operations),
          timestamp,
          current.id,
        );
      this.db.exec("COMMIT");
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
    return this.getAutomation(current.id);
  }

  deleteAutomation(automation) {
    const current = this.#requireAutomation(automation);
    this.db.prepare("DELETE FROM buddy_automations WHERE id = ?").run(current.id);
    return current;
  }

  listDueAutomations(at = new Date()) {
    const due = at instanceof Date ? at.toISOString() : new Date(at).toISOString();
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_automations
        WHERE enabled = 1 AND next_run_at IS NOT NULL AND next_run_at <= ?
        ORDER BY next_run_at, created_at
      `),
      due,
    ).map((row) => this.#automationRow(row));
  }

  claimAutomationRun(
    automation,
    { scheduledFor, idempotencyKey, claimToken, leaseSeconds } = {},
  ) {
    const ownerAutomation = this.#requireAutomation(automation);
    const occurrence = scheduledFor || ownerAutomation.next_run_at || now();
    const scheduled = new Date(occurrence).toISOString();
    const key = idempotencyKey?.trim() || `${ownerAutomation.id}:${scheduled}`;
    const timestamp = now();
    const runId = id("automation_run");
    const token = claimToken?.trim() || id("automation_claim");
    const requestedLeaseSeconds =
      leaseSeconds === undefined
        ? ownerAutomation.policy.max_runtime_seconds + 60
        : Number(leaseSeconds);
    if (!Number.isInteger(requestedLeaseSeconds) || requestedLeaseSeconds < 1) {
      throw new Error("automation claim lease seconds must be a positive integer");
    }
    const claimExpiresAt = new Date(
      Date.parse(timestamp) + requestedLeaseSeconds * 1000,
    ).toISOString();
    try {
      this.db.exec("BEGIN IMMEDIATE");
      const inserted = this.db
        .prepare(`
          INSERT INTO buddy_automation_runs (
            id, automation_id, scheduled_for, idempotency_key, status,
            conversation_id, iteration, outcome, error, claimed_at, started_at, ended_at,
            claim_token, claim_expires_at
          ) VALUES (?, ?, ?, ?, 'claimed', NULL, 0, NULL, NULL, ?, NULL, NULL, ?, ?)
          ON CONFLICT(idempotency_key) DO NOTHING
        `)
        .run(runId, ownerAutomation.id, scheduled, key, timestamp, token, claimExpiresAt);
      if (inserted.changes === 1) {
        this.db
          .prepare(`
            INSERT INTO buddy_automation_run_policies (
              run_id, max_runtime_seconds, max_iterations, max_tokens,
              max_cost_usd, allowed_operations, tokens_used, cost_usd
            ) VALUES (?, ?, ?, ?, ?, ?, 0, 0)
          `)
          .run(
            runId,
            ownerAutomation.policy.max_runtime_seconds,
            ownerAutomation.policy.max_iterations,
            ownerAutomation.policy.max_tokens,
            ownerAutomation.policy.max_cost_usd,
            JSON.stringify(ownerAutomation.policy.allowed_operations),
          );
      } else {
        this.db
          .prepare(`
            UPDATE buddy_automation_runs
            SET status = 'claimed', conversation_id = NULL, iteration = 0,
                outcome = NULL, error = NULL, claimed_at = ?, started_at = NULL,
                ended_at = NULL, claim_token = ?, claim_expires_at = ?
            WHERE idempotency_key = ?
              AND status IN ('claimed', 'running')
              AND (claim_expires_at IS NULL OR claim_expires_at <= ?)
          `)
          .run(timestamp, token, claimExpiresAt, key, timestamp);
      }
      this.db.exec("COMMIT");
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
    const claimed = this.getAutomationRunByIdempotencyKey(key);
    if (claimed?.automation_id !== ownerAutomation.id) {
      throw new Error("idempotency key is already claimed by another automation");
    }
    return {
      ...claimed,
      claim_acquired: claimed.claim_token === token,
    };
  }

  getAutomationRun(run) {
    const row =
      typeof run === "object" && run?.id
        ? run
        : this.db.prepare("SELECT * FROM buddy_automation_runs WHERE id = ?").get(run);
    return row ? this.#automationRunRow(row) : null;
  }

  getAutomationRunByIdempotencyKey(key) {
    const row = this.db
      .prepare("SELECT * FROM buddy_automation_runs WHERE idempotency_key = ?")
      .get(required("idempotency key", key));
    return row ? this.#automationRunRow(row) : null;
  }

  updateAutomationRun(run, {
    status,
    conversationId,
    iteration,
    outcome,
    error,
    nextRunAt,
    tokensUsed,
    costUsd,
    claimToken,
  }) {
    const current = this.#requireAutomationRun(run);
    assertOneOf("automation run status", status, AUTOMATION_RUN_STATUSES);
    if (claimToken !== undefined && current.claim_token !== claimToken) {
      throw new Error("automation run claim is not owned by this executor");
    }
    const terminalStatuses = ["complete", "failed", "cancelled"];
    if (terminalStatuses.includes(current.status)) {
      if (status !== current.status) {
        throw new Error(
          `terminal automation run cannot transition from ${current.status} to ${status}`,
        );
      }
      return current;
    }
    const timestamp = now();
    const startedAt =
      status === "running" ? current.started_at || timestamp : current.started_at;
    const endedAt = terminalStatuses.includes(status)
      ? current.ended_at || timestamp
      : null;
    const nextIteration =
      iteration === undefined ? current.iteration : Math.max(0, Number(iteration) || 0);
    const nextTokensUsed =
      tokensUsed === undefined ? current.tokens_used : Number(tokensUsed);
    const nextCostUsd = costUsd === undefined ? current.cost_usd : Number(costUsd);
    if (!Number.isInteger(nextTokensUsed) || nextTokensUsed < 0) {
      throw new Error("automation tokens used must be a non-negative integer");
    }
    if (!Number.isFinite(nextCostUsd) || nextCostUsd < 0) {
      throw new Error("automation cost used must be non-negative");
    }
    if (nextIteration < current.iteration) {
      throw new Error("automation iteration cannot decrease");
    }
    if (nextTokensUsed < current.tokens_used) {
      throw new Error("automation tokens used cannot decrease");
    }
    if (nextCostUsd < current.cost_usd) {
      throw new Error("automation cost used cannot decrease");
    }
    if (nextIteration > current.policy.max_iterations) {
      throw new Error("automation iteration budget exceeded");
    }
    if (nextTokensUsed > current.policy.max_tokens) {
      throw new Error("automation token budget exceeded");
    }
    if (nextCostUsd > current.policy.max_cost_usd) {
      throw new Error("automation cost budget exceeded");
    }
    if (
      status === "running" &&
      startedAt &&
      Date.parse(timestamp) - Date.parse(startedAt) >
        current.policy.max_runtime_seconds * 1000
    ) {
      throw new Error("automation runtime budget exceeded");
    }
    try {
      this.db.exec("BEGIN");
      this.db
        .prepare(`
          UPDATE buddy_automation_runs SET
            status = ?, conversation_id = ?, iteration = ?, outcome = ?,
            error = ?, started_at = ?, ended_at = ?
          WHERE id = ?
        `)
        .run(
          status,
          conversationId === undefined ? current.conversation_id : conversationId || null,
          nextIteration,
          outcome === undefined ? current.outcome : outcome || null,
          error === undefined ? current.error : error || null,
          startedAt,
          endedAt,
          current.id,
        );
      this.db
        .prepare(`
          UPDATE buddy_automation_run_policies
          SET tokens_used = ?, cost_usd = ?
          WHERE run_id = ?
        `)
        .run(nextTokensUsed, nextCostUsd, current.id);
      if (terminalStatuses.includes(status)) {
        const automation = this.#requireAutomation(current.automation_id);
        const scheduledNextRun =
          nextRunAt === undefined
            ? automation.next_run_at
            : nextRunAt
              ? new Date(nextRunAt).toISOString()
              : null;
        this.db
          .prepare(`
            UPDATE buddy_automations
            SET last_run_at = ?, next_run_at = ?, updated_at = ?
            WHERE id = ?
          `)
          .run(
            automation.last_run_at || timestamp,
            scheduledNextRun,
            timestamp,
            current.automation_id,
          );
      }
      this.db.exec("COMMIT");
    } catch (cause) {
      this.db.exec("ROLLBACK");
      throw cause;
    }
    return this.getAutomationRun(current.id);
  }

  listAutomationRuns(automation, { limit = 50 } = {}) {
    const ownerAutomation = this.#requireAutomation(automation);
    return rows(
      this.db.prepare(`
        SELECT * FROM buddy_automation_runs
        WHERE automation_id = ?
        ORDER BY claimed_at DESC
        LIMIT ?
      `),
      ownerAutomation.id,
      Math.max(1, Number(limit) || 50),
    ).map((row) => this.#automationRunRow(row));
  }

  assertAutomationOperationAllowed(run, operation) {
    const ownerRun = this.#requireAutomationRun(run);
    const name = required("automation operation", operation);
    if (!ownerRun.policy.allowed_operations.includes(name)) {
      throw new Error(`automation operation is not allowed: ${name}`);
    }
    return true;
  }

  linkConversation({
    buddy,
    workspace,
    project,
    workItem,
    provider,
    providerSessionId,
    unleashdConversationId,
    status = "active",
  }) {
    assertOneOf("conversation status", status, CONVERSATION_STATUSES);
    if (!providerSessionId && !unleashdConversationId) {
      throw new Error("provider session id or Unleashd conversation id is required");
    }
    const ownerBuddy = this.#requireBuddy(buddy);
    const item = workItem ? this.#requireWorkItem(workItem) : null;
    const ownerProject = project ? this.#requireBuddyProject(project) : null;
    if (ownerProject && ownerProject.buddy_id !== ownerBuddy.id) {
      throw new Error("Buddy project does not belong to the buddy");
    }
    const ownerWorkspace = this.#requireProject(
      workspace || ownerProject?.workspace_id || item?.project_id || ownerBuddy.project_id,
    );
    this.#requireBuddy(ownerBuddy, ownerWorkspace);
    if (item && item.project_id !== ownerWorkspace.id) {
      throw new Error("legacy work item does not belong to the conversation workspace");
    }
    if (ownerProject && ownerProject.workspace_id !== ownerWorkspace.id) {
      throw new Error("Buddy project does not belong to the conversation workspace");
    }
    const timestamp = now();
    const link = {
      id: id("conversation"),
      buddyId: ownerBuddy.id,
      workspaceId: ownerWorkspace.id,
      buddyProjectId: ownerProject?.id || null,
      workItemId: item?.id || null,
      provider: required("provider", provider),
      providerSessionId: providerSessionId || null,
      unleashdConversationId: unleashdConversationId || null,
      status,
      startedAt: timestamp,
      lastActiveAt: timestamp,
      endedAt: status === "active" ? null : timestamp,
    };
    this.db
      .prepare(`
        INSERT INTO conversation_links (
          id, buddy_id, workspace_id, buddy_project_id, work_item_id, provider, provider_session_id,
          unleashd_conversation_id, status, started_at, last_active_at, ended_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        link.id,
        link.buddyId,
        link.workspaceId,
        link.buddyProjectId,
        link.workItemId,
        link.provider,
        link.providerSessionId,
        link.unleashdConversationId,
        link.status,
        link.startedAt,
        link.lastActiveAt,
        link.endedAt,
      );
    return this.getConversationLink(link.id);
  }

  updateConversationLink(idOrConversationId, {
    status,
    providerSessionId,
  } = {}) {
    const current = this.db
      .prepare(`
        SELECT * FROM conversation_links
        WHERE id = ? OR unleashd_conversation_id = ? OR provider_session_id = ?
      `)
      .get(idOrConversationId, idOrConversationId, idOrConversationId);
    if (!current) throw new Error(`conversation link not found: ${idOrConversationId}`);
    const nextStatus = status || current.status;
    assertOneOf("conversation status", nextStatus, CONVERSATION_STATUSES);
    const timestamp = now();
    this.db
      .prepare(`
        UPDATE conversation_links SET
          status = ?, provider_session_id = COALESCE(?, provider_session_id),
          last_active_at = ?, ended_at = ?
        WHERE id = ?
      `)
      .run(
        nextStatus,
        providerSessionId || null,
        timestamp,
        nextStatus === "active" ? null : timestamp,
        current.id,
      );
    return this.getConversationLink(current.id);
  }

  getConversationLink(id) {
    const row = this.db.prepare("SELECT * FROM conversation_links WHERE id = ?").get(id);
    return row ? { ...row } : null;
  }

  listConversationLinks(buddy) {
    const ownerBuddy = this.#requireBuddy(buddy);
    return rows(
      this.db.prepare(`
        SELECT * FROM conversation_links
        WHERE buddy_id = ?
        ORDER BY last_active_at DESC
      `),
      ownerBuddy.id,
    );
  }

  #projectPath(project, path) {
    return this.#containedPath(project.root_path, required("file path", path));
  }

  #containedPath(root, ...segments) {
    const target = resolve(root, ...segments);
    const fromRoot = relative(root, target);
    if (fromRoot === ".." || fromRoot.startsWith(`..${process.platform === "win32" ? "\\" : "/"}`) || isAbsolute(fromRoot)) {
      throw new Error("memory path escapes the Buddy memory root");
    }
    let probe = target;
    while (!existsSync(probe) && probe !== dirname(probe)) {
      probe = dirname(probe);
    }
    if (existsSync(root) && existsSync(probe)) {
      const realRoot = realpathSync(root);
      const realTarget = realpathSync(probe);
      const realRelative = relative(realRoot, realTarget);
      if (
        realRelative === ".." ||
        realRelative.startsWith(`..${process.platform === "win32" ? "\\" : "/"}`) ||
        isAbsolute(realRelative)
      ) {
        throw new Error("memory path escapes the Buddy memory root");
      }
    }
    return target;
  }

  #memoryRoot(buddy) {
    if (!buddy.memory_path) throw new Error("Buddy has no configured memory path");
    const homeWorkspace = this.#requireProject(buddy.project_id);
    return this.#projectPath(homeWorkspace, buddy.memory_path);
  }

  #insertTodo(projectId, input, timestamp = now()) {
    const status = input.status || "open";
    assertOneOf("todo status", status, BUDDY_TODO_STATUSES);
    if (status === "blocked" && !input.blockedReason?.trim()) {
      throw new Error("blocked reason is required when blocking a todo");
    }
    this.db
      .prepare(`
        INSERT INTO buddy_todos (
          id, buddy_project_id, title, status, position, definition_of_done,
          next_action, blocked_reason, created_at, updated_at, completed_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        id("todo"),
        projectId,
        required("todo title", input.title),
        status,
        Number(input.position) || 0,
        input.definitionOfDone?.trim() || null,
        input.nextAction?.trim() || null,
        status === "blocked" ? input.blockedReason.trim() : null,
        timestamp,
        timestamp,
        ["done", "cancelled"].includes(status) ? timestamp : null,
      );
  }

  #updateTodo(projectId, operation, timestamp) {
    const current = this.db
      .prepare("SELECT * FROM buddy_todos WHERE id = ? AND buddy_project_id = ?")
      .get(required("todo id", operation.todoId), projectId);
    if (!current) throw new Error("todo does not belong to the updated Buddy project");
    const status = operation.status ?? current.status;
    assertOneOf("todo status", status, BUDDY_TODO_STATUSES);
    const blocker =
      status === "blocked"
        ? operation.blockedReason?.trim() || current.blocked_reason
        : null;
    if (status === "blocked" && !blocker) {
      throw new Error("blocked reason is required when blocking a todo");
    }
    this.db
      .prepare(`
        UPDATE buddy_todos SET
          title = ?, status = ?, position = ?, definition_of_done = ?,
          next_action = ?, blocked_reason = ?, updated_at = ?, completed_at = ?
        WHERE id = ?
      `)
      .run(
        operation.title === undefined ? current.title : required("todo title", operation.title),
        status,
        operation.position === undefined
          ? current.position
          : Math.max(0, Number(operation.position) || 0),
        operation.definitionOfDone === undefined
          ? current.definition_of_done
          : operation.definitionOfDone?.trim() || null,
        operation.nextAction === undefined
          ? current.next_action
          : operation.nextAction?.trim() || null,
        blocker,
        timestamp,
        ["done", "cancelled"].includes(status)
          ? current.completed_at || timestamp
          : null,
        current.id,
      );
  }

  #validateAutomationDefinition({
    scheduleKind,
    scheduleExpression,
    timezone,
    jobKind,
    jobPayload,
  }) {
    assertOneOf("schedule kind", scheduleKind, AUTOMATION_SCHEDULE_KINDS);
    assertOneOf("job kind", jobKind, AUTOMATION_JOB_KINDS);
    const expression = required("schedule expression", scheduleExpression);
    if (scheduleKind === "interval") {
      const interval = Number(expression);
      if (!Number.isFinite(interval) || interval <= 0) {
        throw new Error("interval schedule expression must be a positive number of seconds");
      }
    } else if (expression.trim().split(/\s+/).length !== 5) {
      throw new Error("cron schedule expression must contain five fields");
    }
    const zone = required("timezone", timezone);
    try {
      new Intl.DateTimeFormat("en", { timeZone: zone });
    } catch {
      throw new Error(`invalid timezone: ${zone}`);
    }
    if (!jobPayload || typeof jobPayload !== "object" || Array.isArray(jobPayload)) {
      throw new Error("job payload must be an object");
    }
    if (jobKind === "prompt") {
      required("job prompt", jobPayload.prompt);
    } else if (jobKind === "sequence") {
      if (!Array.isArray(jobPayload.prompts) || jobPayload.prompts.length === 0) {
        throw new Error("sequence job requires at least one prompt");
      }
      jobPayload.prompts.forEach((prompt) => required("sequence prompt", prompt));
    } else {
      required("loop prompt", jobPayload.prompt);
      required("loop termination condition", jobPayload.termination?.condition);
      const iterations = Number(jobPayload.termination?.max_iterations);
      const duration = Number(jobPayload.termination?.max_duration_seconds);
      if (!Number.isInteger(iterations) || iterations < 1) {
        throw new Error("loop max_iterations must be a positive integer");
      }
      if (!Number.isFinite(duration) || duration <= 0) {
        throw new Error("loop max_duration_seconds must be positive");
      }
    }
    return {
      scheduleKind,
      scheduleExpression: expression,
      timezone: zone,
      jobKind,
      jobPayload,
    };
  }

  #validateAutomationPolicy(policy, jobKind, jobPayload, current) {
    const plannedIterations =
      jobKind === "prompt"
        ? 1
        : jobKind === "sequence"
          ? jobPayload.prompts.length
          : jobPayload.termination.max_iterations;
    const source = policy || {};
    const fallback = current || {
      max_runtime_seconds: DEFAULT_AUTOMATION_MAX_RUNTIME_SECONDS,
      max_iterations: Math.min(DEFAULT_AUTOMATION_MAX_ITERATIONS, plannedIterations),
      max_tokens: DEFAULT_AUTOMATION_MAX_TOKENS,
      max_cost_usd: DEFAULT_AUTOMATION_MAX_COST_USD,
      allowed_operations: DEFAULT_AUTOMATION_ALLOWED_OPERATIONS,
    };
    const value = {
      max_runtime_seconds:
        source.maxRuntimeSeconds ?? source.max_runtime_seconds ?? fallback.max_runtime_seconds,
      max_iterations:
        source.maxIterations ?? source.max_iterations ?? fallback.max_iterations,
      max_tokens: source.maxTokens ?? source.max_tokens ?? fallback.max_tokens,
      max_cost_usd: source.maxCostUsd ?? source.max_cost_usd ?? fallback.max_cost_usd,
      allowed_operations:
        source.allowedOperations ?? source.allowed_operations ?? fallback.allowed_operations,
    };
    value.max_runtime_seconds = Number(value.max_runtime_seconds);
    value.max_iterations = Number(value.max_iterations);
    value.max_tokens = Number(value.max_tokens);
    value.max_cost_usd = Number(value.max_cost_usd);
    if (!Number.isInteger(value.max_runtime_seconds) || value.max_runtime_seconds < 1) {
      throw new Error("automation max runtime seconds must be a positive integer");
    }
    if (!Number.isInteger(value.max_iterations) || value.max_iterations < 1) {
      throw new Error("automation max iterations must be a positive integer");
    }
    if (!Number.isInteger(value.max_tokens) || value.max_tokens < 1) {
      throw new Error("automation max tokens must be a positive integer");
    }
    if (!Number.isFinite(value.max_cost_usd) || value.max_cost_usd <= 0) {
      throw new Error("automation max cost USD must be positive");
    }
    if (!Array.isArray(value.allowed_operations)) {
      throw new Error("automation allowed operations must be an array");
    }
    value.allowed_operations = [
      ...new Set(
        value.allowed_operations.map((operation) => {
          const name = required("automation allowed operation", operation);
          assertOneOf("automation allowed operation", name, AUTOMATION_ALLOWED_OPERATIONS);
          return name;
        }),
      ),
    ];
    return value;
  }

  #insertAutomationPolicy(automationId, policy, timestamp = now()) {
    this.db
      .prepare(`
        INSERT INTO buddy_automation_policies (
          automation_id, max_runtime_seconds, max_iterations, max_tokens,
          max_cost_usd, allowed_operations, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        automationId,
        policy.max_runtime_seconds,
        policy.max_iterations,
        policy.max_tokens,
        policy.max_cost_usd,
        JSON.stringify(policy.allowed_operations),
        timestamp,
        timestamp,
      );
  }

  #automationRow(row) {
    const policyRow = this.db
      .prepare("SELECT * FROM buddy_automation_policies WHERE automation_id = ?")
      .get(row.id);
    if (!policyRow) throw new Error(`automation policy not found: ${row.id}`);
    return {
      ...row,
      enabled: Boolean(row.enabled),
      job_payload:
        typeof row.job_payload === "string" ? JSON.parse(row.job_payload) : row.job_payload,
      policy: {
        max_runtime_seconds: policyRow.max_runtime_seconds,
        max_iterations: policyRow.max_iterations,
        max_tokens: policyRow.max_tokens,
        max_cost_usd: policyRow.max_cost_usd,
        allowed_operations: JSON.parse(policyRow.allowed_operations),
      },
    };
  }

  #automationRunRow(row) {
    const policyRow = this.db
      .prepare("SELECT * FROM buddy_automation_run_policies WHERE run_id = ?")
      .get(row.id);
    if (!policyRow) throw new Error(`automation run policy not found: ${row.id}`);
    return {
      ...row,
      tokens_used: policyRow.tokens_used,
      cost_usd: policyRow.cost_usd,
      policy: {
        max_runtime_seconds: policyRow.max_runtime_seconds,
        max_iterations: policyRow.max_iterations,
        max_tokens: policyRow.max_tokens,
        max_cost_usd: policyRow.max_cost_usd,
        allowed_operations: JSON.parse(policyRow.allowed_operations),
      },
    };
  }

  #requireProject(idOrSlug) {
    if (typeof idOrSlug === "object" && idOrSlug?.id) {
      return idOrSlug;
    }
    const project = this.getProject(required("project", idOrSlug));
    if (!project) throw new Error(`project not found: ${idOrSlug}`);
    return project;
  }

  #requireBuddy(idOrSlug, project) {
    if (typeof idOrSlug === "object" && idOrSlug?.id) {
      if (project && !this.#buddyHasProject(idOrSlug.id, project.id)) {
        throw new Error("buddy does not belong to the project");
      }
      return idOrSlug;
    }
    const lookup = required("buddy", idOrSlug);
    const buddy = this.getBuddy(lookup, project ? project.id : undefined);
    if (!buddy && project) {
      const buddyInAnotherProject = this.getBuddy(lookup);
      if (buddyInAnotherProject) {
        throw new Error("buddy does not belong to the project");
      }
    }
    if (!buddy) throw new Error(`buddy not found: ${idOrSlug}`);
    if (project && !this.#buddyHasProject(buddy.id, project.id)) {
      throw new Error("buddy does not belong to the project");
    }
    return buddy;
  }

  #buddyHasProject(buddyId, projectId) {
    return Boolean(
      this.db
        .prepare("SELECT 1 FROM buddy_projects WHERE buddy_id = ? AND project_id = ?")
        .get(buddyId, projectId),
    );
  }

  #requireSprint(id, project) {
    if (typeof id === "object" && id?.id) {
      if (project && id.project_id !== project.id) {
        throw new Error("sprint does not belong to the project");
      }
      return id;
    }
    const sprint = this.getSprint(required("sprint", id));
    if (!sprint) throw new Error(`sprint not found: ${id}`);
    if (project && sprint.project_id !== project.id) {
      throw new Error("sprint does not belong to the project");
    }
    return sprint;
  }

  #requireWorkItem(id, projectId) {
    const workItem =
      typeof id === "object" && id?.id
        ? id
        : this.getWorkItem(required("work item", id));
    if (!workItem) throw new Error(`work item not found: ${id}`);
    if (projectId && workItem.project_id !== projectId) {
      throw new Error("work item does not belong to the buddy's project");
    }
    return workItem;
  }

  #requireBuddyProject(project) {
    const ownedProject =
      typeof project === "object" && project?.id
        ? project
        : this.db
            .prepare("SELECT * FROM owned_projects WHERE id = ?")
            .get(required("Buddy project", project));
    if (!ownedProject) throw new Error(`Buddy project not found: ${project}`);
    return ownedProject;
  }

  #requireAutomation(automation) {
    const value = this.getAutomation(automation);
    if (!value) throw new Error(`automation not found: ${automation}`);
    return value;
  }

  #requireAutomationRun(run) {
    const value = this.getAutomationRun(run);
    if (!value) throw new Error(`automation run not found: ${run}`);
    return value;
  }
}
