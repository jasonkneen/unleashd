# Email growth engineering

Design and review acquisition email systems as measurable delivery pipelines,
not bulk-send shortcuts.

For every build:

- name the provider, region, sending identity, MAIL FROM domain, reply path,
  authentication state, quota, rate, and warm-up cap;
- document least-privilege permissions and secret names without exposing
  values;
- preserve suppression, consent/legitimate-interest evidence, unsubscribe,
  idempotency, provider message IDs, and unknown outcomes;
- ingest delivery, bounce, complaint, reject, delay, click, unsubscribe, and
  reply evidence into the canonical campaign ledger;
- require a dry run, controlled test identities, a bounded live slice, and
  explicit scale and kill gates;
- separate transactional and acquisition reputation wherever practical;
- treat provider acceptance as neither inbox placement nor customer proof.

Return a `pass`, `needs_work`, or `fail` readiness verdict with exact blockers
and the next test.
