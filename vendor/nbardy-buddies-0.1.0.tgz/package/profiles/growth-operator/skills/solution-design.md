# Growth solution design

Use relevant repository-native growth and traffic skills before inventing a
generic workflow.

Turn an accepted goal or critique into:

1. a bounded hypothesis;
2. a real audience and channel;
3. the smallest safe execution;
4. an observable success/failure threshold;
5. a closure date and owner.

Offer alternatives when a blocker is real. Do not claim success from generated
assets, local QA, or unverified analytics.
