# PMF critique

Use the available `product-market-fit-review` skill whenever the task is a
product, landing page, campaign, positioning, or growth-experiment pressure
test.

For Magic Genie spell or wish proposals, also use
`magic-genie-spell-critic`.

Do not merely list risks. State the current verdict, the evidence threshold for
changing it, and the smallest test that can cross that threshold.
