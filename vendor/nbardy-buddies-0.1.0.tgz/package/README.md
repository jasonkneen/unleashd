# Buddies

Persistent employees for agent harnesses.

The canonical v1 contracts are:

- [Library, Unleashd, and UI design](docs/DESIGN.md)
- [Implementation plan and todo graph](docs/IMPLEMENTATION_PLAN.md)

A Buddy is not a model process. It is a durable identity that belongs to one
home workspace, may be assigned to additional workspaces, and owns work across many
Codex, Claude, or other provider sessions.

For the bundled employees, the standalone Buddies repository is the home
workspace: it contains their soul and private memory. Product repositories such
as Magic Genie and EventMap are assignments. Every run still selects exactly
one assignment workspace.

```text
Workspace
  └── Buddy assignment (persistent employee)
        ├── soul + memory files in the home workspace
        ├── current sprint work
        └── links to many provider conversations
```

Oompa workers are temporary execution capacity. Buddies are accountable owners.
Unleashd is the control room that can launch conversations for a Buddy and show
the resulting state.

## The minimal idea

Oompa's minimal unit is a disposable worker with a task queue. Buddies has a
different minimal unit:

```text
Buddy = identity + authority + skills + owned work + memory + relationships
```

A Buddy is not a long-running model process. Each model process may stop,
compact, fail, or be replaced. The Buddy remains the same employee because its
identity and state live outside any one conversation.

```text
Click Buddy
    |
    +-- inspect employee, assignments, current work, memory, and history
    |
    +-- talk to Buddy ----------------------+
    |                                      |
    +-- open a specific owned project ------+--> ordinary provider conversation
                                                   + Buddy context metadata
                                                   + BUDDY_SOUL.md
                                                   + scoped memory
                                                   + current work state
                                                   + atomic Buddy tools
```

The minimal useful Buddy therefore has five things:

1. **Identity** — name, role, status, model preferences, and `BUDDY_SOUL.md`.
2. **Assignments** — the workspaces/products the employee is allowed to own.
3. **Owned work** — projects, todos, status, blockers, next actions, and
   definitions of done.
4. **Memory** — durable employee-specific files, separate from conversation
   transcripts.
5. **Team links** — relationships, delegations, reviews, and any number of
   provider conversations attached back to the employee.

A Buddy may work across many assigned workspaces. Every conversation,
delegation, review, and automation run is scoped to exactly one workspace.

Automation is an optional trigger around this core. It starts Buddy work; it
does not define Buddy identity.

## Terminology

There are two meanings of "project" in the current implementation. The product
contract distinguishes them:

| Term | Meaning | Example |
| --- | --- | --- |
| **Workspace** | A repository/product to which a Buddy is assigned | Magic Genie |
| **Buddy project** | A bounded outcome owned by the Buddy | Prove the five-market pilot |
| **Todo** | An atomic step inside a Buddy project | Publish the landing page |
| **Sprint** | A current planning window over Buddy projects | July GTM proof |
| **Conversation** | One model session doing work for the Buddy | A Codex thread |

The existing SQLite table named `projects` is the **workspace** registry.
Canonical Buddy projects and todos live in `owned_projects` and `buddy_todos`.
Legacy `work_items` remain read-only import provenance and are not the active
planning model. A later storage cleanup may rename the workspace table, but the
public contract already exposes it as `workspace`.

## Conversation contract

The directory shows only top-level Buddies. Buddies that report to another
Buddy are summarized by the manager's team count and remain available to the
lead for delegation and review. Clicking a card opens the employee view; it
does not immediately create a model session.

From the employee view:

- **Start conversation** opens an empty general employee conversation. It does
  not send an automatic prompt; the user starts the interaction by talking.
- **Open project** starts or resumes a conversation scoped to that Buddy project.
- A Buddy may own many conversations. No single thread is the Buddy.

In Unleashd, recent Buddy conversations appear in one virtual **Buddies**
folder under **Recent Projects**. The sidebar does not render the employee and
workspace hierarchy.

Buddy conversations use the ordinary Unleashd chat UI and provider runtime.
They only need a typed `buddyContext` attachment and a compact Buddy header card
showing the employee, workspace, owned project, and current state. They do not
need a separate chat implementation.

`buddyContext` must be distinct from all Oompa/swarm metadata. In particular,
Buddy conversations must never be represented with `swarmDebugPrefix` or
rendered with `SwarmConvoPrefix`. Swarms are temporary execution topologies;
Buddies are persistent accountable owners.

Conceptually:

```ts
type BuddyContext = {
  buddyId: string;
  workspaceId: string;
  buddyProjectId?: string | null;
  legacyWorkItemId?: string | null;
  automationRunId?: string | null;
  delegatedByBuddyId?: string | null;
  parentBuddyConversationId?: string | null;
  allowedBuddyOperations?: string[];
};
```

On the first turn, Unleashd deterministically assembles the execution context:

1. Buddy identity and assignment
2. `BUDDY_SOUL.md`
3. the relevant memory summary
4. current sprint and owned-project state
5. the user's prompt or scheduled job prompt

The visible user message stays clean. `buddyContext` is persisted as typed
conversation-creation metadata. On the first provider turn, Unleashd prepends a
hidden briefing containing the soul, memory, and work context; that provider
envelope is an implementation detail, not the durable identity contract.

## Buddy soul and memory

`BUDDY_SOUL.md` is the durable behavioral contract for one employee. It should
contain:

- role and accountability
- decision principles
- communication style
- project authority and approval boundaries
- required end-of-run behavior

It should not contain volatile task status, campaign counts, or a transcript
summary. Those belong in work state and memory.

Each Buddy has one private memory root. A minimal inspectable layout is:

```text
buddies/<buddy-slug>/
├── BUDDY_SOUL.md       # stable behavior and authority
└── memory/
    ├── MEMORY.md       # curated durable facts and decisions
    └── journal/        # append-only run notes and handoffs
```

Workspace evidence remains in the workspace repository. Buddy memory may point
to that evidence, but should not silently become a second source of truth.
“Private” or “quarantined” means the Buddy reads and writes only its configured
memory root through Buddy operations. It is an organizational boundary unless
the provider process is also run in a filesystem sandbox.

Conversation transcripts are history, not memory. A useful fact becomes memory
only through an explicit write or end-of-run compaction step.

## Minimal Buddy tools

Shared state must be changed through deterministic operations, not by asking a
model to edit SQLite or infer state from prose.

The smallest useful mutation surface is:

### `new_project`

Creates a Buddy-owned project in an assigned workspace.

Required input:

- title
- objective
- definition of done

Optional input:

- sprint
- priority
- initial todos
- source/evidence links

### `update_project`

Atomically changes an owned project and its todos. It can:

- update status, blocker, next action, priority, or definition of done
- add, edit, complete, cancel, or reopen todos
- complete, cancel, block, or reopen the project

The operation validates allowed transitions, records timestamps, and returns
the new authoritative state.

### `remember`

Appends a run note or proposes a curated update to the Buddy's memory root. It
cannot rewrite workspace evidence or another Buddy's memory.

Reads such as current Buddy context, project lists, and memory summaries should
be injected automatically or exposed as read-only operations. The mutation
surface should stay small.

The library exposes these mutations through JavaScript and the CLI. Unleashd
registers a conversation-scoped MCP bridge for Codex and requires that bridge
to start successfully for Buddy conversations. The current native surface is:

- `get_current_work`, `get_inbox`, and `get_automations`;
- `new_project`, `update_project`, `remember`, and `compact_memory`;
- disabled-definition automation management through `set_automation`;
- `delegate`, `request_review`, `complete_delegation`, and report-side
  `complete_assignment`;
- `submit_review` and `request_human_approval`.

Identity, workspace, selected project, conversation, automation run, and
delegated operation policy are trusted launch context, not model-supplied tool
arguments. Provider adapters other than Codex still need equivalent native
registration.

### Typed team inbox

Do not add a generic free-form employee mailbox. `get_inbox` projects existing
durable records:

- active assignments received and work delegated to reports;
- recent terminal delegation outcomes with child conversation and completion
  audit evidence;
- assigned reviews;
- pending approvals;
- blocked owned projects;
- latest failed automation runs.

Repository Markdown remains the evidence and handoff layer. The inbox points
to durable work and audit records instead of duplicating documents.

### Delegation and project ownership

`delegate` creates a durable delegation and Unleashd dispatches exactly one
linked child Buddy conversation. The report must explicitly call
`complete_assignment`; a model turn ending does not settle the work.
Schema 10 adds an expiring dispatch claim token, so concurrent executors cannot
bind two child conversations to one delegation and an interrupted claim can be
recovered.

`request_review` lets a Lead assign a structured review to itself or a direct
report for another managed employee. Unleashd launches a least-privilege
reviewer conversation, and `submit_review` persists `pass`, `needs_work`, or
`fail` with evidence and required actions. The Lead's typed inbox projects the
review queue and terminal results across its direct team.
Review requests include explicit input evidence. A declared `reviews`
relationship grants read access to the subject's current work and automation
metadata without granting mutation or management authority.

A delegation may be attached to the manager's owned project for supervision,
but the child does not inherit mutation authority over that project. The
report returns evidence through the assignment and the manager reconciles it
into the parent project.

Delegated Buddy operations are least-privilege. The child conversation
persists an allowed operation list and the MCP server registers only those
Buddy tools. The safe default supports scoped reads, updating an explicitly
named project the report owns, memory handoff, approval request, and assignment
completion. It excludes project creation, automation mutation, recursive
delegation, memory compaction, and manager-side settlement. Prompts describe
the assignment; the operation policy is the enforcement boundary.

The first-turn hidden briefing is bounded. It carries identity, behavior,
workspace and authority rules plus compact soul/skill/memory/work attention
slices; native reads load current detail on demand. Recent journal bodies are
not injected into every conversation.

### Human approval

Approval is durable state, not a phrase in a prompt. A Buddy creates a scoped
request containing the proposed action, reason, and risk. The request remains
`pending` until a named human resolves it `approved` or `rejected`; terminal
requests cannot be changed. Creation and resolution each append an audit event.
Requests may be attached to a Buddy project, linked conversation, and
automation run, and those references must share the same Buddy/workspace scope.

```bash
buddies approval request growth-lead magic-genie "Publish campaign" \
  --reason "Customer-visible state change" \
  --risk "An unsupported claim could be published"

buddies approval resolve approval_123 approved \
  --by nicholas --note "Claims and evidence reviewed."
```

## Minimal automation contract

An automation belongs to a Buddy and starts a bounded job. It does not keep a
model process alive between runs.

```text
Schedule becomes due
  -> acquire one run lease
  -> assemble fresh Buddy context
  -> create and link a conversation
  -> execute job
  -> persist run result, work changes, and memory handoff
  -> schedule next run
```

A minimal automation record needs:

```ts
type BuddyAutomation = {
  id: string;
  buddyId: string;
  workspaceId: string;
  name: string;
  schedule: { kind: "cron" | "interval"; expression: string; timezone: string };
  job:
    | { kind: "prompt"; prompt: string }
    | { kind: "sequence"; prompts: string[] }
    | {
        kind: "loop";
        prompt: string;
        termination: {
          maxIterations: number;
          maxDurationSeconds: number;
          condition: string;
        };
      };
  enabled: boolean;
  policy: {
    maxRuntimeSeconds: number;
    maxIterations: number;
    maxTokens: number;
    maxCostUsd: number;
    allowedOperations: string[];
  };
};
```

Every run needs a durable run record, a unique lease/idempotency key, start and
end timestamps, status, linked conversation, and outcome. A loop must always
have a hard iteration/time ceiling in addition to its semantic termination
condition. Each run snapshots the automation policy at claim time, so later
edits cannot widen an in-flight run. The library rejects recorded iteration,
token, and cost usage above that snapshot and exposes an operation-allowlist
check. New automations default to 600 seconds, at most 10 iterations (and never
more than the job's planned count), 50,000 tokens, USD 2, and read-only
`buddy.get_current_work`.

When Unleashd starts, its scheduler polls immediately. An enabled definition
whose `next_run_at` elapsed while the server was offline receives one
lease-protected catch-up occurrence. Missed ticks are coalesced rather than
replayed, and the next occurrence is calculated from startup/current time.
Disabled definitions never catch up.

Separate overdue definitions are independent and may start concurrently.
Staggered cron times do not express a dependency graph. Work that requires
strict stage ordering must use one bounded sequence or an explicit durable
delegation/review gate; it must not rely only on clock offsets.

The scheduler can remain an Unleashd responsibility. Buddies owns the
automation definition and run history; the provider harness only executes each
conversation.

## What Buddies owns

- Project and Buddy identity
- The active sprint for each project
- Work-item ownership, definition of done, blockers, and next action
- Links between a Buddy, a work item, and provider/Unleashd conversations

## What Buddies does not own

- Model execution or provider CLI flags
- Conversation transcripts
- Vector memory or document indexing
- Slack, Telegram, webhooks, or cron infrastructure
- Swarm orchestration

Personality and memory stay as ordinary repository files. The database stores
paths to those files, not copies of their content.

The "cron infrastructure" boundary means Buddies need not implement a daemon.
It may still own Buddy-specific schedule definitions and run history while
Unleashd supplies the scheduler.

## Current implementation

The SQLite schema is currently version 8:

```text
projects             workspace registry (currently named projects)
buddies              identity, soul/memory paths, provider preferences
buddy_projects       Buddy-to-workspace assignments
sprints              one active sprint per workspace
work_items            owned campaign/task state
conversation_links    Buddy/work-item to provider conversation links
owned_projects        bounded outcomes owned by one Buddy
buddy_todos            atomic steps within an owned project
buddy_automations      validated schedules and bounded job definitions
buddy_automation_runs  idempotent run claims and lifecycle
buddy_automation_policies hard limits and allowed Buddy operations
buddy_automation_run_policies immutable per-run policy snapshots and usage
buddy_relationships    manager/report/consult/review team edges
buddy_skills           named instruction paths and activation modes
buddy_delegations      scoped Buddy-to-Buddy work handoffs
buddy_reviews          structured verdicts and review evidence
buddy_audit_events     append-only records of scoped Buddy operations
buddy_approval_requests pending/approved/rejected human decisions
```

Implemented by the library:

- persistent SQLite identity and assignments
- `BUDDY_SOUL.md`, skill instruction paths, and contained append-only memory
- sprints and flat work items
- atomic Buddy project/todo creation, transitions, completion, and reopening
- conversation linking
- relationship, skill, delegation, and structured review records
- automation definitions, due queries, idempotent claims, and run history
- strict automation policy definitions, per-run snapshots, and usage guards
- durable scoped human approvals with one-way resolution and audit history
- append-only operation audit events
- contained memory compaction with archived journal history
- consistent SQLite backup and migration/version checks

Implemented by Unleashd:

- typed `buddyContext` across shared schemas, pending creation, runtime
  serialization, persisted creation records, and disk hydration
- server-owned Buddy conversation creation and conversation-link lifecycle
- the normal chat UI with a Buddy-specific header independent of Swarms
- employee Work, Conversations, Memory, Automations, delegation, and review
  views
- Buddy HTTP routes and a local scheduler for prompt, sequence, and bounded
  loop jobs, including run-now, cancellation, health, restart recovery, and
  shutdown cleanup
- scoped operation and conversation-closure services with audit records

Current integration status:

- Codex receives the scoped Buddy operations through a required native MCP
  server. If the control plane cannot start, the employee turn fails closed.
- Assignment, delegation, review, and automation conversations close only
  through their explicit typed terminal operations. Ordinary interactive
  employee conversations intentionally remain open across turns.
- Real Codex provider startup/restart and native Lead, Operator, and Critic
  operation calls have been exercised.
- Directory and employee-detail browser QA is complete. Destructive mutation
  flows and a native EventMap automation occurrence remain deliberately gated
  until a disposable target or explicit owner authorization is available.

For the v8 policy surface, Unleashd must additionally:

- expose approval request/list/resolve endpoints and a human decision UI
- make `buddy.request_human_approval` call `createApprovalRequest` rather than
  returning an ephemeral object
- pause or terminate external actions while the request is pending and resume
  only from a durable `approved` record
- use the claimed run's policy snapshot for wall-clock cancellation, provider
  token/cost accounting, and operation dispatch
- call `assertAutomationOperationAllowed` before every Buddy mutation requested
  by an automation

## Storage

The default database is `~/.buddies/buddies.sqlite`. Set `BUDDIES_HOME` to use
another directory. The library uses Node's built-in SQLite driver and has no
runtime dependencies.

Before upgrading or making material manual changes, create a consistent SQLite
backup:

```bash
buddies backup ~/.buddies/backups/buddies-2026-07-28.sqlite
```

The destination must not already exist. Migrations are forward-only. Buddies
refuses to open a database whose schema version is newer than the installed
library; restore a backup or upgrade the library rather than editing
`PRAGMA user_version`.

## Growth Lead starter

This repository includes the initial cross-project Growth Lead profile and an
idempotent importer for the current Magic Genie and EventMap campaign state:

```bash
npm run initialize:growth-lead
```

The initializer discovers `magic_genie` and `event_calendars` beside the
current checkout, or accepts `MAGIC_GENIE_ROOT` and `EVENTMAP_ROOT`.
The importer uses stable external keys, so rerunning it refreshes the canonical
campaign rows instead of duplicating them.

The optional Growth Engineer profile adds a durable technical report to that
existing team without creating campaign state or schedules:

```bash
npm run initialize:growth-engineer
```

Run the Growth Lead initializer first. The Engineer initializer is deliberately
structural: it creates or updates identity, workspace assignments, reporting
lines, and one skill. Current infrastructure and campaign decisions remain in
the product repositories and Buddy projects.

## CLI

```bash
buddies init

buddies workspace add "Magic Genie" ~/git/magic_genie --slug magic-genie

buddies buddy add magic-genie "Growth Lead" \
  --role "Own qualified traffic and campaign closure" \
  --soul growth/BUDDY_SOUL.md \
  --memory growth/agent_notes \
  --provider codex

buddies sprint start magic-genie "July GTM" \
  --goal "Ship and adjudicate one complete campaign"

buddies task add magic-genie "Launch founder-intent campaign" \
  --buddy growth-lead \
  --done "Campaign is live and its first readout is recorded" \
  --next "Approve final creative"

buddies current magic-genie

buddies project new growth-lead magic-genie "Prove founder campaign" \
  --done "A dated carry, sharpen, or kill decision is recorded" \
  --todos-json '[{"title":"Publish"},{"title":"Read results"}]'

buddies context growth-lead --workspace magic-genie

buddies remember growth-lead --kind journal \
  --content "Published the bounded test; readout due Friday."

buddies automation add growth-lead "Friday campaign closure" \
  --workspace magic-genie \
  --schedule-kind cron --schedule "0 16 * * 5" --timezone Asia/Seoul \
  --job-kind prompt --job-json '{"prompt":"Close the current campaign loop."}' \
  --policy-json '{"maxRuntimeSeconds":300,"maxIterations":1,"maxTokens":20000,"maxCostUsd":1,"allowedOperations":["buddy.get_current_work","buddy.update_project","buddy.remember","buddy.request_human_approval"]}'
```

New tasks automatically join the active sprint unless `--sprint` is supplied.
Closed tasks disappear from `current` but remain in SQLite as history.

## Library

```js
import { BuddiesStore } from "@nbardy/buddies";

const buddies = new BuddiesStore();
const current = buddies.currentWork("magic-genie");
buddies.close();
```

The public API returns plain objects whose field names match the SQLite schema.
This keeps adapters thin: Unleashd can expose the objects through an API without
creating a second persistence model.
